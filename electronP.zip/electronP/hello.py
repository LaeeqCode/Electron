from PopBotCheckout.sites.shopify import Shopify
from PopBotCheckout.profile import Profile
print("IN HELLo")
task = {
    "id": "1",
    "user_id": "1",
    "site": "1",
    "profile": "1",
    "profile_id": "1",
    "keyword_url": "https://abominabletoys.com/collections/frontpage/products/limited-edition-abominable-toys-logo-sticker-pack",
    "size": "1",
    "timer": "1",
    "quantity": "1",
    "number_tasks": "1",
    "is_deleted": "1",
    "status": "1",
    "is_captcha": "1",
    "status_color": "1",
    "createdat": "1",
    "site_name": "1",
    "one_checkout": "1",
    "status_title": "1",
    "proxy": "",
}

prof = Profile(
    id="1",
    user_id="1",
    profile_name="1",
    billing_email="test@gmail.com",
    billing_firstname="Michael",
    billing_lastname="Stephens",
    billing_add1="Example St 567",
    billing_add2="",
    billing_city="Coos Bay",
    billing_state="OR",
    billing_country="United States",
    billing_zip="97420",
    billing_phone="5412606611",
    shipping_email="test@gmail.com",
    shipping_firstname="Michael",
    shipping_lastname="Stephens",
    shipping_add1="Example St 567",
    shipping_add2="",
    shipping_city="Coos Bay",
    shipping_state="OR",
    shipping_country="United States",
    shipping_zip="97420",
    shipping_phone="5412606611",
    cardnumber="5481535249725619",
    cvv="101",
    month="12",
    year="2023",
    cardholder="Michael Stephens",
    cardtype="",
    is_deleted="",
    card_unique=""
)

shopify = Shopify(task, prof, None, None, "https://discordapp.com/api/webhooks/720173980492890152/ARCAsRMLiD922ciQATjkzG_0kYpTvuhxEYX_wo_iNmlIT05_64rujbAryPieejzBInDm", "Funko", desktop=True, base="abominabletoys.com")
shopify.checkout()
print("CHECKOUT")