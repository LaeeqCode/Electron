from PopBotCheckout.sites.site import Site
import time
import requests
from bs4 import BeautifulSoup as soup
import threading
from PopBotCheckout.sites.test_config import *
import re
from PopBotCheckout.sites.utility import *
import urllib3
from PopBotCheckout.sites.getCaptcha import get_captcha
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from selenium.webdriver.support.ui import Select
import json
from PopBotCheckout.database import update_title
import random

import os

from time import sleep
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains


import numpy as np
import scipy.interpolate as si

points = [[-6, 2], [-3, -2],[0, 0], [0, 2], [2, 3], [4, 0], [6, 3], [8, 5], [8, 8], [6, 8], [5, 9], [7, 2]];
points = np.array(points)
x = points[:,0]
y = points[:,1]


t = range(len(points))
ipl_t = np.linspace(0.0, len(points) - 1, 100)


x_tup = si.splrep(t, x, k=3)
y_tup = si.splrep(t, y, k=3)

x_list = list(x_tup)
xl = x.tolist()
x_list[1] = xl + [0.0, 0.0, 0.0, 0.0]

y_list = list(y_tup)
yl = y.tolist()
y_list[1] = yl + [0.0, 0.0, 0.0, 0.0]

x_i = si.splev(ipl_t, x_list)
y_i = si.splev(ipl_t, y_list)



headersmain = {
    'accept': 'application/json',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/json; charset=UTF-8',
    'origin': 'https://www.bestbuy.com',
    'referer': 'https://www.bestbuy.com/site/anker-soundcore-liberty-air-2-true-wireless-in-ear-headphones-black/6374960.p?skuId=6374960',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
}


DEFAULT_HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36",
    "origin": "https://www.bestbuy.com",
}

tries = 10
sleep_time = 0.5
the_max = 3

BEST_BUY_ADD_TO_CART_API_URL = "https://www.bestbuy.com/cart/api/v1/addToCart"


class BestBuy(Site):
    def __init__(self, task, profile, celery, r, webhook_url, web_domain, desktop=False, admin_proxies=[]):
        super(BestBuy, self).__init__(task, profile, celery, r, webhook_url, web_domain,)
        self.browser_threads = []
        self.browser = None
        self.display = None


        self.desktop = desktop
        self.searching = 1
        self.valid_browser = False
        self.bad_proxy = False

        self.using_proxy = False

        print("PROXY: {}".format(self.proxy))

        if not self.desktop:
            try:
                p = random.choice(self.proxy)
                if p not in admin_proxies:
                    self.using_proxy = True
                else:
                    print("Using Backend Proxies")
            except:
                p = None
            if p:
                self.ip = p["ip"]
                self.port = p["port"]
                self.username = p["username"]
                self.password = p["password"]
                self.proxy = "{}:{}:{}:{}".format(self.ip,self.port,self.username,self.password)
            else:
                self.proxy = None
        else:
            try:
                self.ip = self.proxy.split(":")[0]
                self.port = self.proxy.split(":")[1]
                self.username = self.proxy.split(":")[2]
                self.password = self.proxy.split(":")[3]
            except:
                pass


    def auto_add_to_cart(self, sku_id, urll):

        body = {"items": [{"skuId": sku_id}]}
        headers = {
            "Accept": "application/json",
            "authority": "www.bestbuy.com",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36",
            "Content-Type": "application/json; charset=UTF-8",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Dest": "empty",
            "origin": "https://www.bestbuy.com",
            "referer": urll,
            "Content-Length": str(len(json.dumps(body))),
        }

        response = self.session.post(
            BEST_BUY_ADD_TO_CART_API_URL, json=body, headers=headers, timeout=5
        )
        if (
                            response.status_code == 200
                    and response.json()["cartCount"] > 0
                and sku_id in response.text
        ):
            print("success!")
        else:
            print("failure!")



    def prod_search(self):
        match = '("offerId":")(.*)(,)'

        if "https:" in self.keyword_url  or "http:" in self.keyword_url:
            stop = self.msg("Adding by Link..", "#FFC300")
            if stop:
                return "stop", None
            if "?skuId=" in self.keyword_url:
                return self.keyword_url.split("?skuId=")[1], self.keyword_url
            else:
                return self.keyword_url.split("/")[-1].replace(".p", ""), self.keyword_url
        else:
            words = self.keyword_url.split(" ")

            if len(words) == 1:
                if words[0][0] != "-" and words[0][0] != "+":
                    stop = self.msg("Adding by PID..", "#FFC300")
                    if stop:
                        return "stop", None
                    #                 url = "https://www.walmart.com/ip/item/{}".format(words[0])
                    #                  s = requests.get(url, headers=headersmain)
                    #                   result = re.search(match, s.text)
                    #                    offerID = result.group(2).split('"')[0]
                    return self.keyword_url, "https://www.bestbuy.com/site/fff/{}.p?skuId={}".format(self.keyword_url, self.keyword_url)

            new_words = []
            for w in words:
                if w[0] == "-":
                    pass
                else:
                    new_words.append(w[1:])

            #print(new_words)



            base_url = "https://www.bestbuy.com/site/searchpage.jsp?st={}&_dyncharset=UTF-8&_dynSessConf=&id=pcat17071&type=page&sc=Global&cp=1&nrp=&sp=&qp=&list=n&af=true&iht=y&usc=All+Categories&ks=960&keys=keys".format("+".join(new_words))
            #print(base_url)
            try:
                search_url = "https://api.bestbuy.com/v1/products(search={})?format=json&show=sku,name,salePrice&apiKey=AjP8mN7NBsD51HHva25TU6dv".format("&search=".join(new_words))


                #self.browser.get(base_url)
                #session = requests.session()
                # = session.get(base_url)
                while True:

                    stop = self.msg("Searching..[{}]".format(self.searching), '#FFC300')
                    #print(self.browser.page_source)
                    #time.sleep(900)
                    if stop:
                        return "stop", None
                    #send_screenshot(self.browser, ".")


                    items = []
                    i = 1
                    while i <= 10:
                        the_url = search_url + "&page={}".format(i)
                        s = self.session_get(the_url, headers=headersmain)
                        data = json.loads(s.text)
                        items += list(data["products"])


                        for item in items:
                            title = item["name"]
                            sku = item["sku"]

                            #print(title)

                            if verify_keywords(title, words):
                                stop = self.msg("Found product..", "#FFC300")
                                if stop:
                                    return "stop", None

                                the_title = title
                                print(the_title)
                                self.product_title = the_title

                                try:
                                    update_title(self.task, self.r, the_title)
                                except:
                                    pass

                                return sku, "https://www.bestbuy.com/site/fff/{}.p?skuId={}".format(sku, sku)

                        if int(i) >= int(data["totalPages"]):
                            break
                        i += 1


                    break


            except Exception as e:
                print("except Tiles")
                print_error_info(e)
                if self.bad_proxy is True:
                    self.msg("BAD PROXY", "#FF0000")
                self.stop()
                return "stop", None

            #session.close()


            return None, None

    def browser_thread(self):
        try:
            print("making browser..")
            if self.proxy:
                splits = self.proxy.split(":")
                self.browser = get_chromedriver(splits[0], splits[1], splits[2], splits[3], use_proxy=True, headless=(not self.desktop))
            else:
                self.browser = get_chromedriver("", "", "", "", use_proxy=False, headless=(not self.desktop))
            print("browser created..")
            self.browser.get("http://bestbuy.com/asdfasdf")

            count=0
            while True:

                if "something wrong with the proxy server" in self.browser.page_source.lower() or "ERR_EMPTY_RESPONSE" in self.browser.page_source.lower() or "page isn’t working" in self.browser.page_source.lower():
                    self.browser_thread_complete = True
                    print("No Internet..")
                    self.bad_proxy = True
                    break
                elif "best" in self.browser.title.lower():
                    self.browser_thread_complete = True
                    break
                elif "<html><head></head><body></body></html>" in self.browser.page_source.lower():
                    count += 1
                    if count >= 40:
                        self.browser_thread_complete = True
                        print("Blank Page..")
                        self.bad_proxy = True
                        break
        except Exception as e:
            print(str(e))
            self.browser_thread_complete = True

    def do_mouse_moves(self):
        return
        global the_max
        action =  ActionChains(self.browser)

        startElement = self.browser.find_element_by_css_selector('body')
        #First, go to your start point or Element
        action.move_to_element(startElement)
        action.perform()

        c = 0
        max = the_max
        for mouse_x, mouse_y in zip(x_i, y_i):
            action.move_by_offset(mouse_x,mouse_y)
            action.perform()
            #sleep(0.001)
            #print(mouse_x, mouse_y)
            c += 1
            if c >= max:
                the_max += 3
                print("added new max: {}".format(the_max))
                break

    def in_stock(self, sku_id):
        url = "https://www.bestbuy.com/api/tcfb/model.json?paths=%5B%5B%22shop%22%2C%22scds%22%2C%22v2%22%2C%22page%22%2C%22tenants%22%2C%22bbypres%22%2C%22pages%22%2C%22globalnavigationv5sv%22%2C%22header%22%5D%2C%5B%22shop%22%2C%22buttonstate%22%2C%22v5%22%2C%22item%22%2C%22skus%22%2C{}%2C%22conditions%22%2C%22NONE%22%2C%22destinationZipCode%22%2C%22%2520%22%2C%22storeId%22%2C%22%2520%22%2C%22context%22%2C%22cyp%22%2C%22addAll%22%2C%22false%22%5D%5D&method=get".format(
            sku_id
        )
        response = self.session.get(url, headers=DEFAULT_HEADERS)
        #log.info(f"Stock check response code: {response.status_code}")
        try:
            response_json = response.json()
            item_json = find_values(
                json.dumps(response_json), "buttonStateResponseInfos"
            )
            item_state = item_json[0][0]["buttonState"]
            #log.info(f"Item state is: {item_state}")
            if int(item_json[0][0]["skuId"]) == int(sku_id) and item_state in [
                "ADD_TO_CART",
                "PRE_ORDER",
            ]:
                return True
            else:
                return False
        except Exception as e:
           # log.warning("Error parsing json. Using string search to determine state.")
            #log.info(response_json)
            #log.error(e)
            if "ADD_TO_CART" in response.text:
                #log.info("Item is in stock!")
                return True
            else:
                #log.info("Item is out of stock")
                return False

    def checkout(self):
        self.msg("Creating session..", "#FFC300")
        try:
            if not self.verify_profile():
                self.msg("Incomplete Profile", '#FF0000')
                return

            self.browser_threads = []
            self.browser_threads.append(threading.Thread(target=self.browser_thread))
            self.browser_thread_started = True
            self.browser_thread_complete = False
            for thread in self.browser_threads:
                thread.start()

            if self.bad_proxy:
                self.msg("BAD PROXY", "#FF0000")
                self.stop()
                return

            if self.proxy:
                print("adding proxy..")
                self.session.proxies = {"https": "https://{}".format("{}:{}@{}:{}".format(self.username, self.password, self.ip, self.port))}

            the_link = False
            count = 0
            while not the_link:
                count += 1
                if count >= tries:
                    time.sleep(sleep_time)
                the_link, website = self.prod_search()
                for thread in self.browser_threads:
                    thread.join()
                self.browser.get(website)
                if the_link == "stop":
                    print("STOPP")
                    self.stop()
                    return
                if the_link:
                    if self.browser_thread_started and self.browser_thread_complete and self.browser is None:
                        self.browser_threads = []
                        self.browser_threads.append(threading.Thread(target=self.browser_thread))
                        self.browser_thread_started = True
                        self.browser_thread_complete = False
                        for thread in self.browser_threads:
                            thread.start()
                    break
                else:
                    if self.browser_thread_started and self.browser_thread_complete:
                        for thread in self.browser_threads:
                            thread.join()
                        self.stop()

            sku_id = the_link

            self.msg("Getting cookies..", '#FFC300')


            while True:
                if self.in_stock(sku_id):
                    break
                else:
                    self.msg("Waiting for Restock..", "#FFC300")
                    time.sleep(0.1)

            stop = self.msg("Adding to cart..", '#FFC300')
            if stop:
                self.stop()
                return



            count2 = 0

            #self.do_mouse_moves()
            while True:
                count2 += 1
                if count2 >= tries:
                    time.sleep(sleep_time)
                try:

                    bs = soup(str(self.browser.page_source), "html.parser")
                    the_title = bs.find('div', {"class": 'sku-title'}).get_text()
                    print(the_title)
                    self.product_title = the_title.replace("New!", "")

                    try:
                        update_title(self.task, self.r, the_title)
                    except:
                        pass
                except:
                    pass

                if not self.product_title:
                    continue

                try:
                    #self.auto_add_to_cart(sku_id, "https://bestbuy.com")




                    self.browser.get("https://api.bestbuy.com/click/5592e2b895800000/{}/cart".format(sku_id))
                    breakout = False
                    while True:
                        if "cart - best buy" in self.browser.title.lower() and '"cart-item__title focus' in self.browser.page_source.lower():
                            breakout = True
                            break
                        elif "your cart is empty" in self.browser.page_source.lower():
                            #self.msg("Couldn't Add to Cart", "#FF0000")
                            #self.browser.get("https://bestbuy.com")

                            self.do_mouse_moves()

                            break
                        else:
                            time.sleep(0.1)
                    if breakout:
                        break

                except Exception as e:
                    print(str(e) + "\nTRYING AGAIN..")
                    #send_screenshot(self.browser, "..")


                    #self.browser.get(self.the_url)

            self.msg("Getting cookies..", '#FFC300')

            stop = self.msg("Going to checkout..", '#FFC300')
            if stop:
                self.stop()
                return

            request_cookies_browser = self.browser.get_cookies()
            c = [self.session.cookies.set(c['name'], c['value']) for c in request_cookies_browser]

            for c in self.session.cookies:
                cook = {'name': c.name, 'value': c.value, 'path': c.path}
                self.browser.add_cookie(cook)


            #self.browser.get("https://www.bestbuy.com/cart")

            # update_url = "https://www.bestbuy.com/site/canopy/component/shop/master-ad/v1?cart=%7B%22cartItems%22%3A%5B%7B%22id%22%3A%22{}%22%2C%22price%22%3A%22%22%2C%22quantity%22%3A1%7D%5D%7D&locale=en-US&pageType=cart".format(the_link)
            #
            # strng = self.browser.execute_script("return document.cookie")
            #
            # s = self.session_post(update_url, headers={
            #     "accept": "*/*",
            #     "accept-encoding": "gzip, deflate, br",
            #     "accept-language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
            #     "referer": "https://www.bestbuy.com/cart",
            #     "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.69 Safari/537.36",
            #     'sec-fetch-dest': 'empty',
            #     'sec-fetch-mode': 'cors',
            #     'sec-fetch-site': 'same-origin',
            #     'x-client-id': 'shop.master-ad.v1',
            #     'cookie': strng
            # }, timeout=3)



            #time.sleep(9000)

            # while True:
            #     try:
            #         selecter = self.browser.find_element_by_css_selector("select.fluid-item__quantity")
            #         if selecter:
            #             select = Select(selecter)
            #             select.select_by_value("1")
            #             break
            #     except:
            #         pass

            self.browser.get("https://www.bestbuy.com/checkout/r/fulfillment")

            count3 = 0
            while True:
                count3 += 1
                if count3 >= tries:
                    time.sleep(sleep_time)
                if "cart" in self.browser.title.lower():
                    print("cart in")
                    self.browser.get("https://www.bestbuy.com/checkout/r/fulfillment")

                if 'class="streamlined__switch"' in self.browser.page_source.lower():
                    if "switch to shipping" in self.browser.page_source.lower():
                        isButton = self.browser.execute_script("return document.querySelector('a.ispu-card__switch')")
                        if isButton:
                            self.browser.execute_script("document.querySelector('a.ispu-card__switch').click();")
                            break
                    else:
                        break
                else:
                    send_screenshot(self.browser, ".'")

            stop = self.msg("Submitting shipping..", '#FFC300')
            if stop:
                self.stop()
                return
            count4 = 0
            while True:
                count4 += 1
                if count4 >= tries:
                    time.sleep(sleep_time)
                self.msg("Filling form..", '#FFC300')


                set_and_verify(self.browser, "div.address-form__first-name input", self.billing_firstname, send_keys=True, ya=True)
                set_and_verify(self.browser, "div.address-form__last-name input", self.billing_lastname, send_keys=True, ya=True)
                set_and_verify(self.browser, "div.address-form__cell input", self.billing_add1, send_keys=True, ya=True, num=2)
                set_and_verify(self.browser, "div.address-form__city input", self.billing_city, send_keys=True, ya=True)
                set_and_verify(self.browser, "div.address-form__zip input", self.billing_zip, send_keys=True, ya=True)

                if len(self.billing_add2) > 0:
                    self.browser.execute_script('document.querySelector("button.address-form__showAddress2Link").click()')
                    time.sleep(0.1)
                    set_and_verify(self.browser, '.line2 input', self.billing_add2, send_keys=True, ya=True)

                try:
                    select = Select(self.browser.find_element_by_css_selector('div.address-form__state select'))
                    select.select_by_value(self.billing_state)
                except Exception as e:
                    pass

                set_and_verify(self.browser, "input#user\\.emailAddress", self.billing_email, send_keys=True, ya=True)
                set_and_verify(self.browser, "input#user\\.phone", self.billing_phone, send_keys=True, ya=True)
                self.browser.execute_script('document.querySelector(".button--continue button").click()')

                break

            stop = self.msg("Submitting billing..", '#FFC300')
            if stop:
                self.stop()
                return
            count5 = 0
            missing = False
            while True:
                count5 += 1
                if count5 >= tries:
                    time.sleep(sleep_time)
                self.msg("Filling form..", '#FFC300')
                c = 0
                count6 = 0
                while True:
                    count6 += 1
                    if count6 >= tries:
                        time.sleep(sleep_time)
                    if "heads up" in self.browser.page_source.lower():
                        self.msg("Waiting for Response..", "#FFC300")

                        if "no longer available for shipping" in self.browser.page_source.lower():
                            self.msg("Unavailable To Ship", "#FF0000")
                            self.stop()
                            return

                        try:
                            self.browser.execute_script("window.scrollTo(0, document.body.scrollHeight)")
                        except:
                            pass
                        time.sleep(sleep_time)
                        c += 1
                        #print(c)

                        try:
                            self.browser.execute_script('document.querySelector(".button--continue button").click()')
                        except:
                            pass
                    isButton = self.browser.execute_script("return document.querySelector('input#optimized-cc-card-number')")
                    if isButton:
                        #print("isButton")
                        break

                set_and_verify(self.browser, "input#optimized-cc-card-number", self.cardnumber, send_keys=True, ya=True)
                if "please enter a valid card number" in self.browser.page_source.lower():
                    print("WTFFF")
                isCVV = self.browser.execute_script("return document.querySelector('input#credit-card-cvv')")
                if not isCVV:
                    missing = True
                    break
                set_and_verify(self.browser, "input#credit-card-cvv", self.cardcvv, send_keys=True, ya=True)

                try:
                    select = Select(self.browser.find_elements_by_css_selector('div.col-xs-6 select')[0])
                    select.select_by_value(self.expmonth)
                except Exception as e:
                    pass

                try:
                    select = Select(self.browser.find_elements_by_css_selector('div.col-xs-6 select')[1])
                    select.select_by_value(self.expyear)
                except Exception as e:
                    pass

                self.browser.execute_script('document.querySelectorAll("button.btn-block")[1].click()')
                stop = self.msg("Checkout completed..", "#FFC300")
                if stop:
                    self.stop()
                    return

                break

            count7 = 0
            clicked = False
            while True:
                count7 += 1
                if count7 >= tries:
                    time.sleep(sleep_time)

                try:
                    if not clicked:
                        self.browser.execute_script('document.querySelector("div.button--place-order button.btn-block").click()')
                        clicked = True
                except:
                    pass

                if missing:
                    self.msg("Invalid Card Info", '#FF0000')
                    break

                if "unable to process your credit card" in self.browser.page_source.lower():
                    self.msg("Card Declined", '#FF0000')
                    break

                if "account required" in self.browser.page_source.lower():
                    self.msg("Account Required", '#FF0000')
                    break

                if "thanks for shopping with us" in self.browser.page_source.lower():
                    self.msg("Successful Checkout", '#00FF00')
                    break
            self.stop()
        except Exception as e:
            print(str(e))
            print_error_info(e)
            self.stop()
            pass

if __name__ == "__main__":

    desktop=True
    disney = BestBuy(task, prof, None, None, 0, 0, desktop=True)
    disney.checkout()
