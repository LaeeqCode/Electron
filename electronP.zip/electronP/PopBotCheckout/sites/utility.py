from discord_webhook import DiscordWebhook
from selenium.webdriver.common.keys import Keys
import sys
import os
import zipfile
from selenium import webdriver
from selenium.webdriver import DesiredCapabilities
import uuid

def send_screenshot(browser, content):

    browser.save_screenshot("pic.png")
    webhook = DiscordWebhook(url="https://discordapp.com/api/webhooks/720173980492890152/ARCAsRMLiD922ciQATjkzG_0kYpTvuhxEYX_wo_iNmlIT05_64rujbAryPieejzBInDm", content="```" + str(content) + "```")
    with open("pic.png", "rb") as f:
        webhook.add_file(file=f.read(), filename="pic.png")
    return webhook.execute()

import json


def find_values(json_repr, id):
    results = []

    def _decode_dict(a_dict):
        try:
            results.append(a_dict[id])
        except KeyError:
            pass
        return a_dict

    json.loads(json_repr, object_hook=_decode_dict)  # Return value ignored.
    return results


class InvalidAutoBuyConfigException(Exception):
    def __init__(self, message):
        super().__init__(message)


def print_error_info(e):
    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
    print(str(e), exc_type, fname, exc_tb.tb_lineno)


def set_and_verify(browser, css, val, ignores=[], send_keys=False, ya=False, lst=False, num=0):
    while True:
        try:
            #print(val)
            ignores.append("/")

            if not send_keys:
                nameHolder = browser.find_element_by_css_selector(css)
                browser.execute_script("arguments[0].value='{}';".format(val), nameHolder)
            else:
                if "select" not in css and not ya:

                    if lst is False:
                        change_str = 'var element = document.querySelector("{}");element.value="{}";var event = new Event("change");element.dispatchEvent(event);var event = new Event("blur");element.dispatchEvent(event);var event = new Event("focus");element.dispatchEvent(event);'.format(css, val)
                        browser.execute_script(change_str)
                    else:
                        strr = ""
                        i = 0
                        for i in range(len(css)):
                            change_str = 'var element = document.querySelector("{}");element.value="{}";var event = new Event("change");element.dispatchEvent(event);var event = new Event("blur");element.dispatchEvent(event);var event = new Event("focus");element.dispatchEvent(event);'.format(css[i], val[i])
                            strr += change_str
                            i += 1
                            browser.execute_script(strr)
                    # pyperclip.copy(val)
                    # nameHolder.send_keys(Keys.CONTROL, "v")
                    #nameHolder.send_keys(val)
                else:
                    if not num:
                        nameHolder = browser.find_element_by_css_selector(css)
                    else:
                        nameHolder = browser.find_elements_by_css_selector(css)[num]
                    nameHolder.send_keys(val)
            if lst:
                break
            nameHolder = browser.find_elements_by_css_selector(css)[num]
            value = nameHolder.get_attribute('value')
            base1 = "".join(val.split())
            base2 = "".join(value.split())

            for i in ignores:
                base1 = base1.replace(i, "")
                base2 = base2.replace(i, "")

            if base1 != base2:
                print(base1, base2)
                if 1==1:
                    browser.execute_script("arguments[0].value='';", nameHolder)
                else:
                    nameHolder.send_keys(Keys.BACK_SPACE * (len(value)+1))
                #print("Retrying")
            else:
                break
        except Exception as e:
            pass
            pass


def verify_keywords(title, keywords):
    pos_kw = []
    neg_kw = []

    for k in keywords:
        if k[0] == "+":
            pos_kw.append(k[1:])
        elif k[0] == "-":
            neg_kw.append(k[1:])

    matches = 0
    for p in pos_kw:
        if p.lower() in title.lower():
            matches += 1

    if matches == len(pos_kw):
        for n in neg_kw:
            if n.lower() in title.lower():
                return False
        return True
    return False

def get_chromedriver(PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS, use_proxy=False, user_agent=None, headless=True):

    if use_proxy:
        manifest_json = """
{
    "version": "1.0.0",
    "manifest_version": 2,
    "name": "Chrome Proxy",
    "permissions": [
        "proxy",
        "tabs",
        "unlimitedStorage",
        "storage",
        "<all_urls>",
        "webRequest",
        "webRequestBlocking"
    ],
    "background": {
        "scripts": ["background.js"]
    },
    "minimum_chrome_version":"22.0.0"
}
"""

    background_js = """
var config = {
        mode: "fixed_servers",
        rules: {
        singleProxy: {
            scheme: "http",
            host: "%s",
            port: parseInt(%s)
        },
        bypassList: ["localhost"]
        }
    };

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "%s",
            password: "%s"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
            callbackFn,
            {urls: ["<all_urls>"]},
            ['blocking']
);
""" % (PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS)



    try:
        options = {
           # 'connection_keep_alive': True,
            'backend': 'mitmproxy',
            'connection_timeout': 5,
            'proxy': {
                'http': 'http://{}:{}@{}:{}'.format(PROXY_USER, PROXY_PASS, PROXY_HOST, PROXY_PORT),
                'https': 'https://{}:{}@{}:{}'.format(PROXY_USER, PROXY_PASS, PROXY_HOST, PROXY_PORT)
            }
        }
    except Exception as e:
        print(str(e))
        pass

    options2 = {
       # 'connection_keep_alive': True,
        'connection_timeout': 5,
        'verify_ssl': False,
        'suppress_connection_errors': False
    }

    prefs = {"profile.managed_default_content_settings.images": 2}

    pluginfile = 'proxy_auth_plugin_{}.zip'.format(uuid.uuid4())
    chrome_options = webdriver.ChromeOptions()
    if use_proxy:

        with zipfile.ZipFile(pluginfile, 'w') as zp:
            zp.writestr("manifest.json", manifest_json)
            zp.writestr("background.js", background_js)
        chrome_options.add_extension(pluginfile)
    if user_agent:
        chrome_options.add_argument('--user-agent=%s' % user_agent)
    #if headless:
    #    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--no-sandbox")
    #chrome_options.add_experimental_option("prefs", prefs)
    #chrome_options.add_argument('--ignore-certificate-errors')
    #chrome_options.add_argument('--ignore-ssl-errors')
    caps = DesiredCapabilities().CHROME
    caps["pageLoadStrategy"] = "none"



    if use_proxy:
        print("USIN PROXY")
        driver = webdriver.Chrome(
            desired_capabilities=caps,
            chrome_options=chrome_options)
    else:
        print("NOT USIN PROXY")
        driver = webdriver.Chrome(
            desired_capabilities=caps,
            chrome_options=chrome_options)
    try:
        os.remove(pluginfile)
    except:
        pass
    return driver
