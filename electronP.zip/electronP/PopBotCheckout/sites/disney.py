from PopBotCheckout.sites.site import Site
import requests
from bs4 import BeautifulSoup as soup
import threading
from selenium.webdriver.common.action_chains import ActionChains
from PopBotCheckout.sites.test_config import *
from PopBotCheckout.sites.utility import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import time
from PopBotCheckout.database import update_title
import random

headersmain = {
    'accept': '*/*',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    #'cache-control': 'max-age=0',
    #'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
    'origin': 'https://www.shopdisney.com',
    'referer': 'https://www.shopdisney.com/chip-mug-beauty-and-the-beast-400020128157.html?isProductSearch=1&plpPosition=2&searchType=regular',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',

}

triesx = 10
sleep_time = 0.5

class Disney(Site):
    def __init__(self, task, profile, celery, r, webhook_url, web_domain, desktop=False, admin_proxies=[]):
        super(Disney, self).__init__(task, profile, celery, r, webhook_url, web_domain,)
        self.browser_threads = []
        self.browser = None
        self.desktop = desktop
        self.searching = 1
        self.restock = False
        self.browser = False
        self.valid_browser = False
        self.banned = False
        self.using_proxy = False

        if not self.desktop:
            try:
                p = random.choice(self.proxy)
                if p not in admin_proxies:
                    self.using_proxy = True
                else:
                    print("Using Backend Proxies")
            except:
                p = None
            if p:
                self.ip = p["ip"]
                self.port = p["port"]
                self.username = p["username"]
                self.password = p["password"]
                self.proxy = "{}:{}:{}:{}".format(self.ip,self.port,self.username,self.password)
            else:
                self.proxy = None
        else:
            try:
                self.ip = self.proxy.split(":")[0]
                self.port = self.proxy.split(":")[1]
                self.username = self.proxy.split(":")[2]
                self.password = self.proxy.split(":")[3]
            except:
                pass


    def prod_search(self):
        if "https:" in self.keyword_url or "http:" in self.keyword_url:
            if not self.restock:
                stop = self.msg("Adding by Link..", "#FFC300")
                if stop:
                    return "stop"
            return self.keyword_url
        else:
            words = self.keyword_url.split(" ")

            if len(words) == 1:
                if words[0][0] != "-" and words[0][0] != "+":
                    if not self.restock:
                        stop = self.msg("Adding by PID..", "#FFC300")
                        if stop:
                            return "stop"
                    return "-" + str(words[0]) + ".html"

            new_words = []
            for w in words:
                if w[0] == "-":
                    pass
                else:
                    new_words.append(w)

            if not self.restock:
                stop = self.msg("Searching..", '#FFC300')
                if stop:
                    return "stop"

            base_url = "https://www.shopdisney.com/search?q={}".format("+".join(new_words))
            s = self.session_get(base_url, headers=headersmain)
            bs = soup(s.text, "html.parser")
            tiles = bs.find_all("a", {"class": "product__tile_link"})
            for tile1 in tiles:
                title = tile1.get_text()
                link = tile1["href"]

                if verify_keywords(title, words):
                    if not self.restock:
                        stop = self.msg("Found product..", "#FFC300")
                        if stop:
                            return "stop"
                    return link

            return None

    def browser_thread(self):
        try:
            if self.proxy:
                splits = self.proxy.split(":")
                self.browser = get_chromedriver(splits[0], splits[1], splits[2], splits[3], use_proxy=True, headless=(not self.desktop))
                #self.msg("Adding Proxy..", "#FF0000")
            else:
                self.browser = get_chromedriver("", "", "", "", use_proxy=False, headless=(not self.desktop))
            self.browser.get("https://www.shopdisney.com/gifts-content/")

            while True:
                if self.browser.execute_script("return document.querySelector('a.nav-logo')"):
                    self.browser_thread_complete = True
                    break
                if "denied" in self.browser.page_source.lower():
                    self.banned = True
                    self.browser_thread_complete = True
                    break

                if "ERR_TUNNEL_CONNECTION_FAILED" in self.browser.page_source or "something wrong with the proxy server" in self.browser.page_source.lower() or "didn't send any data" in self.browser.page_source.lower():
                    self.banned = True
                    self.browser_thread_complete = True
                    break
                else:
                    print()
        except Exception as e:
            print(str(e))
            self.browser_thread_complete = True

    def checkout(self):
        self.msg("Creating session..", "#FFC300")
        if not self.verify_profile():
            self.msg("Incomplete Profile", '#FF0000')
            return

        self.startT = time.time()
        try:
            self.browser_threads = []
            self.browser_threads.append(threading.Thread(target=self.browser_thread))
            self.browser_thread_started = True
            self.browser_thread_complete = False
            for thread in self.browser_threads:
                thread.start()

            for thread in self.browser_threads:
                thread.join()

            if self.banned:
                self.msg("Bad Proxy", '#FF0000')
                self.stop()
                return

            self.session = requests.session()
            request_cookies_browser = self.browser.get_cookies()
            c = [self.session.cookies.set(c['name'], c['value']) for c in request_cookies_browser]

            if self.proxy:
                self.session.proxies = {"https": "https://{}".format("{}:{}@{}:{}".format(self.username, self.password, self.ip, self.port))}
            #c = [self.session.cookies.set(c['name'], c['value']) for c in request_cookies_browser]
            self.msg("Getting cookies..", '#FFC300')

            if "united states" in self.billing_country.lower():
                self.billing_country = "US"
                self.shipping_country = "US"


            count = 0
            while True:
                count += 1
                if count >= triesx:
                    time.sleep(sleep_time)
                found = False
                count2 = 0
                while not found:
                    count2 += 1
                    if count2 >= triesx:
                        time.sleep(sleep_time)
                    found = self.prod_search()
                    if found == "stop":
                        self.stop()
                        return
                    #print(found)
                    if found:
                        if self.browser_thread_started and self.browser_thread_complete and self.browser is None and not self.restock:
                            self.browser_threads = []
                            self.browser_threads.append(threading.Thread(target=self.browser_thread))
                            self.browser_thread_started = True
                            self.browser_thread_complete = False
                            for thread in self.browser_threads:
                                thread.start()
                    else:
                        if self.browser_thread_started and self.browser_thread_complete and not self.restock:
                            for thread in self.browser_threads:
                                thread.join()
                            self.stop()
                pid = found.split(".html")[0].split("-")[-1]


                self.browser.get("https://www.shopdisney.com/test-{}.html".format(pid))
                print(pid)
                atc_url = 'https://www.shopdisney.com/on/demandware.store/Sites-shopDisney-Site/default/Cart-AddProduct'
                num = 10
                count3 = 0
                while True:
                    count3 += 1
                    if count3 >= triesx:
                        #time.sleep(sleep_time)
                        pass
                    try:
                        self.browser.execute_script("window.scrollTo(0, 0)")
                        print(self.browser.title)
                        #send_screenshot(self.browser, ".")
                        #strng = self.browser.execute_script("return document.cookie")

                        atc_button = self.browser.find_element_by_css_selector("button.add-to-cart")
                        if atc_button:
                            while True:
                                time.sleep(1)
                                if 'class="veil"' not in self.browser.page_source:
                                    if 'Sold Out</button>'.lower() not in self.browser.page_source.lower():
                                        self.browser.execute_script("arguments[0].click()", atc_button)
                                        print("CLICKING!!")
                                        send_screenshot(self.browser, ".")
                                    else:
                                        self.msg("Waiting for Restock..", "#FFC300")
                                        self.browser.get("https://www.shopdisney.com/test-{}.html".format(pid))
                                if '<span class="minicart-quantity">1</span>' in self.browser.page_source.lower():
                                    break


                        #c = [self.session.cookies.set(c['name'], c['value']) for c in request_cookies_browser]
                        # s = self.session_post(atc_url, headers={**headersmain}, data={
                        #     "pid": pid,
                        #    "quantity": "1",
                        #     "productGuestCategory": "movies & shows-star wars-star wars: the mandalorian"
                        # }, timeout=5)
                        break
                    except Exception as e:
                        time.sleep(1)
                        print(str(e))


                #cookies = s.cookies.get_dict()
                text = self.browser.page_source.lower()
                #                print(s.text.lower())
                if "cannot be added to cart" in text or "currently unavailable" in text:
                    stop = self.msg("Waiting for Restock..", "#FFC300")
                    if stop:
                        self.stop()
                        return
                    self.restock = True
                    if self.browser_thread_started and self.browser_thread_complete and self.restock:
                        for thread in self.browser_threads:
                            thread.join()
                        self.stop()
                else:
                    self.keyword_url = found
                    if self.browser_thread_started and self.browser_thread_complete and self.browser is None:
                        self.browser_threads = []
                        self.browser_threads.append(threading.Thread(target=self.browser_thread))
                        self.browser_thread_started = True
                        self.browser_thread_complete = False
                        for thread in self.browser_threads:
                            thread.start()
                    break


                    #          self.msg("Adding to cart..", '#FFC300')

                #            s = session.get("https://www.shopdisney.com/my-bag?validateBasket=1", headers=headersmain, cookies=cookies, verify=False)

                #            cookies = s.cookies.get_dict()

                #           self.msg("Going to checkout..", '#FFC300')


                #            cookies = s.cookies.get_dict()

            stop = self.msg("Submitting shipping..", '#FFC300')
            if stop:
                self.stop()
                return

            while True:
                try:
                    request_cookies_browser = self.browser.get_cookies()
                    c = [self.session.cookies.set(c['name'], c['value']) for c in request_cookies_browser]

                    s = self.session_get("https://www.shopdisney.com/ocapi/cc/checkout?validateCheckout=1", headers=headersmain)

                    s = self.session_get("https://www.shopdisney.com/checkout?stage=shipping#", headers=headersmain)
                    cookies = s.cookies.get_dict()

                    self.msg("Getting cookies..", '#FFC300')

                    bs = soup(s.text, "html.parser")
                    title = bs.find('h4', {"class": 'product-line-item__title'}).get_text()
                    self.product_title = title
                    try:
                        update_title(self.task, self.r, title)
                    except:
                        pass
                    break
                except:
                    pass

            bs = soup(s.text, "html.parser")

            originalShipmentUUID = bs.find("input", {"name": "originalShipmentUUID"}).get("value")
            shipmentUUID = bs.find("input", {"name": "shipmentUUID"}).get("value")
            csrf_token = bs.find("input", {"name": "csrf_token"}).get("value")

            shipping_payload = {
                'originalShipmentUUID': originalShipmentUUID,
                'shipmentUUID': shipmentUUID,
                'dwfrm_shipping_shippingAddress_addressFields_firstName': self.billing_firstname,
                'dwfrm_shipping_shippingAddress_addressFields_lastName': self.billing_lastname,
                'dwfrm_shipping_shippingAddress_addressFields_country': self.billing_country,
                'dwfrm_shipping_shippingAddress_addressFields_postalCode': self.billing_zip,
                'dwfrm_shipping_shippingAddress_addressFields_address1': self.billing_add1,
                'dwfrm_shipping_shippingAddress_addressFields_address2': self.billing_add2,
                'dwfrm_shipping_shippingAddress_addressFields_city': self.billing_city,
                'dwfrm_shipping_shippingAddress_addressFields_states_stateCode': self.billing_state,
                'dwfrm_shipping_shippingAddress_addressFields_phone': self.billing_phone,
                'shippingMethod': '88 lane 0 standard',
                'csrf_token': csrf_token
            }

            validate_shipping = "https://www.shopdisney.com/on/demandware.store/Sites-shopDisney-Site/default/CheckoutAddressServices-ValidateAddress"
            s = self.session_post(validate_shipping, headers={**headersmain, }, cookies=cookies, data=shipping_payload)
            cookies = s.cookies.get_dict()

            next_link = 'https://www.shopdisney.com/on/demandware.store/Sites-shopDisney-Site/default/CheckoutShippingServices-SubmitShipping'
            s = self.session_post(next_link, headers=headersmain, cookies=cookies, data=shipping_payload)
            cookies = s.cookies.get_dict()

            #            session.get("https://www.shopdisney.com/on/demandware.store/Sites-shopDisney-Site/default/CheckoutOrderSummaryRefresh-Show", headers=headersmain, cookies=cookies, verify=False)
            #            refresh_url = "https://www.shopdisney.com/checkout?stage=payment#payment"
            #            session.get(refresh_url, headers=headersmain, cookies=cookies, verify=False)

            stop = self.msg("Submitting billing..", '#FFC300')
            if stop:
                self.stop()
                return


            for c in self.session.cookies:
                cook = {'name': c.name, 'value': c.value, 'path': c.path}
                self.browser.add_cookie(cook)

            self.browser.get("https://www.shopdisney.com/checkout?stage=payment#payment")
            self.msg("Getting cookies..", '#FFC300')
            #    time.sleep(90000)

            daFrame = False
            count4 = 0
            while True:
                count4 += 1
                if count4 >= triesx:
                    time.sleep(sleep_time)
                stop = self.msg("Filling form..", '#FFC300')
                if count4 % 20 == 0:
                    send_screenshot(self.browser, ".")
                if stop:
                    self.stop()
                    return
                try:
                    if not daFrame:
                        self.browser.switch_to.default_content()
                        actions = ActionChains(self.browser)
                        actions.send_keys(Keys.TAB * 1)
                        actions.perform()

                    try:
                        self.browser.switch_to.default_content()
                        frame1 = self.browser.execute_script("return document.querySelector('iframe#payui-main')")
                        self.browser.switch_to.frame(frame1)
                        elements = self.browser.find_elements_by_css_selector("input")
                        #print(elements)
                        if len(elements) >= 3:
                            self.browser.execute_script("arguments[0].click()", elements[2])
                            # for e in elements:
                            #     self.browser.execute_script("arguments[0].click()", e)
                            #e.click()
                        #self.browser.find_elements_by_css_selector("input#primaryCard-CREDIT_CARD")[0].click()
                        self.browser.execute_script("document.querySelector('input#primaryCard-CREDIT_CARD').click()")
                    except Exception as e:
                        print(str(e))
                        pass
                    self.browser.switch_to.default_content()
                    daFrame = self.browser.execute_script("return document.querySelector('iframe#payui-main')")
                    if not daFrame:
                        continue
                    self.browser.switch_to.frame(daFrame)


                    try:
                        no_pay = self.browser.find_element_by_css_selector("p.no-payment-required")
                        if no_pay:
                            self.msg("Cart Empty", "#FF0000")
                            self.stop()
                            return
                    except Exception as e:
                        pass

                    nameHolder = self.browser.execute_script("return document.querySelector('input#cardNumber-CREDIT_CARD')")
                    if not nameHolder:
                        continue

                    str_month = self.expmonth
                    str_year = self.expyear
                    if len(str_month) == 1:
                        str_month = "0" + str_month
                    if len(str_year) == 4:
                        str_year = str_year[2:]

                    print("FILLING CARD")
                    #time.sleep(5)
                    #send_screenshot(self.browser, ".")
                    set_and_verify(self.browser, "input#cardNumber-CREDIT_CARD", self.cardnumber, send_keys=True, ya=True)
                    set_and_verify(self.browser, "input#expiration-CREDIT_CARD", "{}/{}".format(str_month, str_year), send_keys=True, ya=True)
                    set_and_verify(self.browser, "input#securityCode-CREDIT_CARD", self.cardcvv, send_keys=True, ya=True)
                    set_and_verify(self.browser, "input#cardholderName", self.cardname, send_keys=True, ya=True)
                    #                    self.stop()
                    #                    return

                    break
                except Exception as e:
                    print(str(e))
                    pass

            self.browser.execute_script("window.scrollTo(0, document.body.scrollHeight);")




            stop = self.msg("Checkout completed..", '#FFC300')
            if stop:
                self.stop()
                return

            quit_now = False

            tries = 0
            count5 = 0
            while True:
                self.browser.switch_to.default_content()
                count5 += 1
                if count5 >= triesx:
                    time.sleep(sleep_time)
                try:
                    if tries >= 1000:
                        quit_now = True
                        print("QUIT NOW")
                        break

                    try:
                        button = self.browser.find_element_by_css_selector('.submit-payment')
                        self.browser.execute_script("arguments[0].click()", button)
                    except:
                        pass

                    try:
                        daFrame = self.browser.execute_script("return document.querySelector('iframe#payui-main')")
                        self.browser.switch_to.frame(daFrame)
                        texxt = self.browser.execute_script('return document.querySelector("span.ng-tns-c19-7")')
                        if "valid card number" in str(texxt.text):
                            quit_now = True
                            self.browser.switch_to.default_content()
                        break
                    except Exception as e:
                        print(str(e))
                        pass

                    self.browser.switch_to.default_content()

                    email = self.browser.find_element_by_css_selector('input#contactEmail')
                    email.send_keys(self.billing_email)

                    first = self.browser.find_element_by_css_selector('input#billingFirstName')
                    first.send_keys(self.billing_firstname)
                    last = self.browser.find_element_by_css_selector('input#billingLastName')
                    last.send_keys(self.billing_firstname)
                    phn = self.browser.find_element_by_css_selector('input#contactPhoneNumberFormatted')
                    phn.send_keys(self.billing_phone)

                    button = self.browser.find_element_by_css_selector('.submit-payment')
                    self.browser.execute_script("arguments[0].disabled = false;", button)
                    self.browser.execute_script("arguments[0].click()", button)
                    break
                except:
                    tries += 1


            curr_title = str(self.browser.title)
            counter = 0
            count6 = 0
            while True:
                count6 += 1
                if count6 >= triesx:
                    time.sleep(sleep_time)
                # if 1==1:
                #     self.msg("Successful Checkout?", "#FFC300")
                #     break
                counter += 1
                if counter >= 1000:
                    self.msg("Timed Out", '#FF0000')
                    break
                new_title = str(self.browser.title)
                if new_title != curr_title:
                    print(new_title, curr_title)
                    self.msg("Successful Checkout", '#00FF00')
                    break

                try:
                    if quit_now:
                        self.msg("Invalid Card Info", '#FF0000')
                        break
                    if "use a different card to continue.</div>" in self.browser.page_source.lower():
                        self.msg("Card Declined", '#FF0000')
                        #send_screenshot(self.browser, "..")
                        break

                        # else:
                        #     self.msg("FAIL", '#FF0000')
                        #import time
                        # time.sleep(900)

                except:
                    pass

            self.stop()

        except Exception as e:
            print(str(e))
            self.stop()

    def verify_profile(self):
        return super().verify_profile()


if __name__ == "__main__":
    disney = Disney(task, prof, None, None, "google", "google", desktop=True)
    disney.checkout()