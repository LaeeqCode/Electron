
import requests
import time
from PopBotCheckout.database import update_redis
from discord_webhook import DiscordWebhook, DiscordEmbed
from PopBotCheckout.database import get_task

from PopBotCheckout.sites.utility import *

class Site:
    def __init__(self, task, profile, celery, r, webhook_url, web_domain, desktop=False):
        self.browser_thread_started = False
        self.browser_thread_complete = False
        self.browser = None
        self.task = task
        self.task_id = task["id"]
        self.user_id = task['user_id']
        self.site = task['site']
        self.r = r
        self.profile = task['profile']
        self.profile_id = task['profile_id']
        self.keyword_url = task['keyword_url']
        self.size = task['size']
        self.timer = task['timer']
        self.quantity = task['quantity']
        self.number_tasks = task['number_tasks']
        self.is_captcha = task['is_captcha']
        if self.is_captcha == '1':
            self.is_captcha = True

        self.proxy = task["proxy"]

        self.billing_email = profile.billing_email
        self.billing_firstname = profile.billing_firstname
        self.billing_lastname = profile.billing_lastname
        self.billing_add1 = profile.billing_add1
        self.billing_add2 = profile.billing_add2
        self.billing_city = profile.billing_city
        self.billing_state = profile.billing_state #province
        self.billing_country = profile.billing_country
        self.billing_zip = profile.billing_zip
        self.billing_phone = profile.billing_phone
        self.cardnumber = profile.cardnumber
        self.cardcvv = profile.cvv
        self.expmonth = profile.month
        self.expyear = profile.year
        self.cardname = profile.cardholder

        self.celery = celery
        self.desktop = desktop

        self.webhook_url = webhook_url
        self.web_domain = web_domain

        self.product_title = None

        self.session = requests.session()
        self.using_proxy = False
        #self.db = db

    def checkout(self):
        pass

    def show_ip(self):
        self.browser.get("https://ipinfo.io")
        time.sleep(10)
        send_screenshot(self.browser, ".")

    def stop(self):
        print("STOPPING!!!")

        try:
            self.browser.quit()
            self.browser = None

        except Exception as e:
            pass
            #print("+ " + str(e))

    def verify_profile(self):
        if not self.billing_email:
            return False
        if not self.billing_firstname:
            return False
        if not self.billing_lastname:
            return False
        if not self.billing_add1:
            return False
        if not self.billing_city:
            return False
        if not self.billing_state:
            return False
        if not self.billing_country:
            return False
        if not self.billing_zip:
            return False
        if not self.billing_phone:
            return False
        if not self.cardnumber:
            return False
        if not self.cardcvv:
            return False
        if not self.expmonth:
            return False
        if not self.expyear:
            return False
        if not self.cardname:
            return False
        return True

    def session_get(self, url, max_tries=10, delay=0.5, headers=None, cookies=None, timeout=1, allow_redirects=False):
        count = 0
        while True:
            count += 1
            if count >= max_tries:
                time.sleep(delay)
                if count % max_tries == 0:
                    task = get_task(self.task, self.r)
                    if 'stopped' in task['status'].lower():
                        return "stop"
            try:
                if allow_redirects:
                    s = self.session.get(url, headers=headers, cookies=cookies, verify=False, timeout=timeout, allow_redirects=True)
                    if "443" in str(s):
                        self.msg("Request Blocked", "FF0000")
                    return s
                else:
                    s = self.session.get(url, headers=headers, cookies=cookies, verify=False, timeout=timeout)
                    if "443" in str(s):
                        self.msg("Request Blocked", "FF0000")
                    return s
            except Exception as e:
                print("site.session_get error: {}".format(e))
                if "443" in str(e):
                    self.msg("Request Blocked", "FF0000")
                if count >= 40:
                    return False

    def session_post(self, url, max_tries=10, delay=0.5, headers=None, cookies=None, data=None, json=None, timeout=1):
        count = 0
        while True:
            count += 1
            if count >= max_tries:
                time.sleep(delay)
                if count % max_tries == 0:
                    task = get_task(self.task, self.r)
                    if 'stopped' in task['status'].lower():
                        return False
            try:
                return self.session.post(url, headers=headers, cookies=cookies, data=data, json=json, verify=False, timeout=timeout)
            except Exception as e:
                print("site.session_post error: {}".format(e))
                if count >= 40:
                    return False

    def msg(self, msg, clr):

        print(msg)

        try:
            try:
                task = get_task(self.task, self.r)
                if 'stopped' in task['status'].lower():
                    return True
            except Exception as e:
                #print(str(e))
                pass


            if not self.desktop:
                self.celery.update_state(state=msg, meta={'status_color': clr})
                update_redis(self.task, self.r, msg, clr)




            if "successful" in msg.lower() and "google" not in self.webhook_url:
                webhook = DiscordWebhook(url=self.webhook_url)

                embed = DiscordEmbed(title="PopBot Checkout", color=0x63FF94)

                embed.set_footer(text='PopBot Checkout')
                # set image
                embed.set_thumbnail(url='https://pbs.twimg.com/profile_images/1170100637658275840/KDBGqwoD_400x400.jpg')


                embed.add_embed_field(name='Item', value="{}".format(self.product_title), inline=False)
                embed.add_embed_field(name='Size', value='R', inline=True)
                embed.add_embed_field(name='Profile', value=self.profile, inline=True)

                if self.using_proxy:
                    embed.add_embed_field(name='Proxy', value="{}".format(self.proxy))
                else:
                    embed.add_embed_field(name='Proxy', value="None")

                embed.add_embed_field(name='Site', value=self.web_domain, inline=False)
                embed.set_timestamp()

                # add embed object to webhook
    #            print(webhook.__dict__)
                webhook.add_embed(embed)
                print(webhook.__dict__)
                response = webhook.execute()
                print(response)
        except Exception as e:
            print_error_info(e)



    def random_proxy(self):
        return None

    def recaptcha(self):
        url = "http://2captcha.com/in.php"
        resp = requests.get(url)
        if resp.text[0:2] != 'OK':
            quit()  #CAPTCHA IS NOT RECEIVED
        captcha_id = resp.text[3:]
        print("captcha_id: ", captcha_id)
        # fetch ready 'g-recaptcha-response' token for captcha_id
        fetch_url = "http://2captcha.com/res.php"
        for i in range(1, 120):
            time.sleep(5)  # wait 5 sec.
            resp = requests.get(fetch_url)
            if resp.text[0:2] == 'OK':
                break
        print('Google response token: ', resp.text[3:])
        value = resp.text[3:]
        return value