
import csv
import requests
from bs4 import BeautifulSoup
import random
import time
from datetime import datetime, timedelta
from datetime import time as tme
import string
import os
import lxml
import imghdr
import traceback
import mysql.connector
from datetime import datetime, timedelta
from datetime import time as tme
import io
import ssl
import json
import base64
import copy
import smtplib
import sys
import urllib
#from urllib.parse import urlencode, quote
from requests_toolbelt.multipart.encoder import MultipartEncoder


ss = sys.getdefaultencoding()

StopBot = False

config = {
    'user': 'root',

}

class Task():


    def __init__(self, id,user_id,site,profile ,profile_id,keyword_url, size,timer,quantity,number_tasks, is_deleted,status,is_captcha):
        self.id = id
        self.user_id = user_id
        self.site = site
        self.profile = profile
        self.profile_id = profile_id
        self.keyword_url = keyword_url
        self.size = size
        self.timer = timer
        self.quantity = quantity
        self.number_tasks = number_tasks
        self.is_deleted = is_deleted
        self.status = status
        self.is_captcha = is_captcha


class Profile():


    def __init__(self, id,user_id,profile_name,billing_firstname ,billing_lastname,billing_add1,billing_add2,billing_city,billing_zip,billing_country, billing_state,billing_phone,billing_email,shipping_firstname,shipping_lastname,shipping_add1,shipping_add2,shipping_city,shipping_zip,shipping_country,shipping_state,shipping_phone,shipping_email,cardnumber,year,month,cardtype,cvv,cardholder,is_deleted,card_unique):
        self.id = id
        self.user_id = user_id
        self.profile_name = profile_name
        self.billing_firstname = billing_firstname
        self.billing_lastname = billing_lastname
        self.billing_add1 = billing_add1
        self.billing_add2 = billing_add2
        self.billing_city = billing_city
        self.billing_zip = billing_zip
        self.billing_country = billing_country
        self.billing_state = billing_state
        self.billing_phone = billing_phone
        self.billing_email = billing_email
        self.shipping_firstname = shipping_firstname
        self.shipping_lastname = shipping_lastname
        self.shipping_add1 = shipping_add1
        self.shipping_add2 = shipping_add2
        self.shipping_city = shipping_city
        self.shipping_zip = shipping_zip
        self.shipping_country = shipping_country
        self.shipping_state = shipping_state
        self.shipping_phone = shipping_phone
        self.shipping_email = shipping_email
        self.cardnumber = cardnumber
        self.year = year
        self.month = month
        self.cardtype = cardtype
        self.cvv = cvv
        self.cardholder = cardholder
        self.is_deleted = is_deleted
        self.card_unique = card_unique

class Card():

    def __init__(self, cardnumber,month,year,cvv):
        self.cardnumber = cardnumber
        self.month = month
        self.year = year
        self.cvv = cvv


def recaptcha(checkout_url):
    url = "http://2captcha.com/in.php"
    resp = requests.get(url)
    if resp.text[0:2] != 'OK':
        quit('Error. Captcha is not received')
    captcha_id = resp.text[3:]
    print("captcha_id :", captcha_id)
    # fetch ready 'g-recaptcha-response' token for captcha_id
    fetch_url = "http://2captcha.com/res.php"
    for i in range(1, 120):
        time.sleep(5)  # wait 5 sec.
        resp = requests.get(fetch_url)
        if resp.text[0:2] == 'OK':
            break
    print('Google response token: ', resp.text[3:])
    global value
    value = resp.text[3:]
    return value


def UpdateStatus(task_id,status,clor):
    global rows_log

    connection = mysql.connector.connect(**config)
    cursor = connection.cursor()
    cursor.execute("UPDATE task SET status=%s , status_color=%s WHERE id = %s" ,(status,clor,task_id) )
    connection.commit()
    cursor.close()
    connection.close()



def Kith(rr,pf):

    global update_tasks
    global update_tasks_title
    try:

        taskid = rr.id
        userid = rr.user_id
        site = rr.site

        profile = rr.profile
        profileid = rr.profile_id
        keywordurl = rr.keyword_url
        size = rr.size
        timer = rr.timer
        quantity = rr.quantity
        notask = rr.number_tasks
        is_captcha = rr.is_captcha
        if is_captcha == '1':
            is_captcha = True
        else:
            is_captcha = False

        product_size = size

        Website_DOMAIN = site

        prx = random_proxy()

        email = pf.billing_email
        first_name = pf.billing_firstname
        last_name = pf.billing_lastname
        add1 = pf.billing_add1
        add2 = pf.billing_add2
        city = pf.billing_city
        province = pf.billing_state
        country = pf.billing_country
        zip = pf.billing_zip
        phone = pf.billing_phone
        cardnumber = pf.cardnumber
        #cardnumber = dt[0].replace('"','')
        cardcvv = pf.cvv
        expmonth = pf.month
        if '0' in expmonth:
            expmonth = expmonth.replace('0','')
        expyear = pf.year
        cardname = pf.cardholder


        s = sess()
        checkout_text = ''

        if 'http' in product_url:

            r2 = s.get(product_url)
            checkout_text = r2.text
        else:


            ts = time.time()
            ts = int(ts)
            ts = str(ts)


        json_object = json.loads(checkout_text)
        size_array = json_object
        size_array2 = size_array['product']['variants']
        size =''

        if product_size:
            if product_size == 'RANDOM' or product_size == 'OS':
                for sz in size_array2:
                    variant_id = sz['id']
                    variant_id = str(variant_id)
            else:
                for sz in size_array2:
                    size = sz['title']

                if (size==product_size):
                    variant_id = sz['id']
                    variant_id = str(variant_id)
                    variant_id = variant_id.replace('L','')
        else:
            sz = size_array2[0]
            variant_id = sz['id']
            variant_id = str(variant_id)
            variant_id = variant_id.replace('L','')


        addtocart_payload = {'id':variant_id,'quantity':'1' }



        r3 = s.post(Website_DOMAIN,data=addtocart_payload)

        if "is already sold out" in s3:

            update_tasks.append(UpdateTask(taskid,'Soldout','#EA3447'))


        elif "Cannot find variant" in s3:

            update_tasks.append(UpdateTask(taskid,'Cannot find variant','#EA3447'))


        else:

            update_tasks.append(UpdateTask(taskid,'Cart Added','#FFC300'))


            payload = ''

            r4 = s.post(Website_DOMAIN+'/cart',data=payload)

            authencity_token = r4.find('input', attrs={'name':'authenticity_token'})
            at = authencity_token['value']


            ReffUrl = checkout_url

            cap_token = ''

            if is_captcha:

                while "03" not in cap_token:

                    s_tok = Get_CaptchaToken(taskid)

                    cap_token = s_tok
                    cap_token =  cap_token.replace('"','').replace('\n','')


            checkout_payload5 = {
                'checkout[email]':email,
                'checkout[shipping_address][first_name]':first_name,
                'checkout[shipping_address][last_name]':'',
                'checkout[shipping_address][address1]':add1,
                'checkout[shipping_address][address2]':'',
                'checkout[shipping_address][city]':city,
                'checkout[shipping_address][country]':country,
                'checkout[shipping_address][province]':province,
                'checkout[shipping_address][zip]':zip,
                'checkout[shipping_address][phone]':phone,
                'checkout[shipping_address][first_name]':first_name,
                'checkout[shipping_address][last_name]':last_name,
                'checkout[shipping_address][address1]':add1,
                'checkout[shipping_address][address2]':'',
                'checkout[shipping_address][city]':city,
                'checkout[shipping_address][country]':country,
                'checkout[shipping_address][province]':province,
                'checkout[shipping_address][zip]':zip,
                'checkout[shipping_address][phone]':phone,
                'g-recaptcha-response':cap_token
            }



            r5 = s.post(checkout_url,data= checkout_payload5)


            if "Captcha validation failed. Please try again." in r5:

                update_tasks.append(UpdateStatus(taskid,'Captcha Failed','#EA3447'))

            else:

                authencity_token = r5.find('input', attrs={'name':'authenticity_token'})


                checkout_payload6 = {
                    'utf8':'✓',
                    '_method':'patch',
                    'authenticity_token':at,

                }

                r6 = s.post(checkout_url,data= checkout_payload6)


                if "Processing order" in r6:

                    if "Thank you for your purchase" in r6:

                        update_tasks.append(UpdateTask(taskid,'Success','#00FF00'))





    except:
        update_tasks.append(UpdateTask(taskid,'Failed','#EA3447'))




def Funko(rr,pf):

    global update_tasks
    global update_tasks_title
    try:
        taskid = rr.id
        userid = rr.user_id
        site = rr.site

        profile = rr.profile
        profileid = rr.profile_id
        keywordurl = rr.keyword_url
        size = rr.size
        timer = rr.timer
        quantity = rr.quantity
        notask = rr.number_tasks
        is_captcha = rr.is_captcha
        if is_captcha == '1':
            is_captcha = True
        product_url = keywordurl

        product_size = size

        Website_DOMAIN = site

        prx = random_proxy()

        email = pf.billing_email
        first_name = pf.billing_firstname
        last_name = pf.billing_lastname
        add1 = pf.billing_add1
        add2 = pf.billing_add2
        city = pf.billing_city
        province = pf.billing_state
        country = pf.billing_country
        zip = pf.billing_zip
        phone = pf.billing_phone
        cardnumber = pf.cardnumber
        #cardnumber = dt[0].replace('"','')
        cardcvv = pf.cvv
        expmonth = pf.month
        if '0' in expmonth:
            expmonth = expmonth.replace('0','')
        expyear = pf.year
        cardname = pf.cardholder



        Site_url=site
        if 'http' in product_url:
            s = sess()


            r3=s.get(product_url)

        else:
            Search_KS = product_url
            Search_KS_list = Search_KS.split(',')

        Quantity = quantity

        Cartdata = MultipartEncoder(fields={
            'utf8':'✓',
            'add':'',
            'id':Id,
            'quantity':Quantity,
            'form_type':'product'

        })

        CartUrl="https://shop.funko.com/cart/add"
        r4=s.post(CartUrl ,data=Cartdata)



        CheckOutData = {
            'checkout': 'Check Out',
            'updates[]': Quantity,
        }

        CheckOuturl = "https://shop.funko.com/cart"
        CheckOutReq=s.post(CheckOuturl ,data=CheckOutData)


        authencity_token = CheckOutReq.find('input', attrs={'name':'authenticity_token'})
        at = authencity_token['value']

        checkout_url = ''


        shipping_id = ''

        ReffUrl = checkout_url

        cap_token = ''

        if is_captcha:

            while "03" not in cap_token:

                s_tok = Get_CaptchaToken(taskid)
                #s_tok = recaptcha(checkout_url)
                cap_token = s_tok
                cap_token =  cap_token.replace('"','').replace('\n','')




        checkout_payload5 = {

            'checkout[email]':email,

            'checkout[shipping_address][first_name]':first_name,
            'checkout[shipping_address][last_name]':'',
            'checkout[shipping_address][address1]':add1,
            'checkout[shipping_address][address2]':'',
            'checkout[shipping_address][city]':city,
            'checkout[shipping_address][country]':country,
            'checkout[shipping_address][province]':province,
            'checkout[shipping_address][zip]':zip,
            'checkout[shipping_address][phone]':phone,
            'checkout[shipping_address][first_name]':first_name,
            'checkout[shipping_address][last_name]':last_name,
            'checkout[shipping_address][address1]':add1,
            'checkout[shipping_address][address2]':'',
            'checkout[shipping_address][city]':city,
            'checkout[shipping_address][country]':country,
            'checkout[shipping_address][province]':province,
            'checkout[shipping_address][zip]':zip,
            'checkout[shipping_address][phone]':phone,
            'g-recaptcha-response':cap_token
        }


        r5 = s.post(checkout_url,data= checkout_payload5)


        if "Captcha validation failed. Please try again." in ss5:


            update_tasks.append(UpdateTask(taskid,'Captcha Failed','#EA3447'))


        else:



            input1 =  r5.find('input', attrs={'name':'previous_step'})
            input2 = input1.find_previous_sibling('input')
            at = input2['value']

            shipping_method = souper.find('div', attrs={'class':'radio-wrapper'})


            checkout_payload6 = {
                #'utf8':'✓',
                '_method':'patch',
                'authenticity_token':at,
            }

            refurl = checkout_url+"?previous_step=contact_information&step=shipping_method"

            r6 = s.post(checkout_url,data= checkout_payload6)

            authencity_token = souper.find('input', attrs={'name':'authenticity_token'})



            checkout_payload8 = {
                #'utf8':'✓',
                '_method':'patch',
                'authenticity_token':at,
                'previous_step':'payment_method',
                'step':'',
                's':sid,

            }



            r7 = s.post(checkout_url,data= checkout_payload8)

            if "Processing order" in r7:

                if "Thank you for your purchase" in r7:

                    update_tasks.append(UpdateTask(taskid,'SUCCESS','#00FF00'))





    except Exception as e:

        update_tasks.append(UpdateTask(taskid,'Failed','#EA3447'))

        pass




tasks = []
profiles =[]
update_tasks = []
update_tasks_title = []

def get_Profile():
    global profiles
    while True:

        connection = mysql.connector.connect(**config)
        connection.autocommit = True
        cursor = connection.cursor()
        cursor.execute("SELECT  * from profile where is_deleted = 0 ")
        tsks = cursor.fetchall()


def main():
    global StopBot



    while StopBot == False:
        global profiles
        global update_tasks
        connection = mysql.connector.connect(**config)
        connection.autocommit = True
        cursor = connection.cursor()

        cursor.execute("SELECT  * from task where status = 'started' and is_deleted = 0")
        tsks = cursor.fetchall()
        if len(tsks) > 0:
            for row in tsks:
                web_domain = row[2]
                taskid = row[0]
                userid = row[1]
                profileid = row[4]
                tasks.append(Task(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[17]))
                tskss = Task(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[17])

                for pf in profiles:
                    pfid = pf['id']
                    if int(pfid) == int(profileid):

                        pflss = Profile(pf['id'],pf['user_id'],pf['profile_name'],pf['billing_firstname'],pf['billing_lastname'],pf['billing_add1'],pf['billing_add2'],pf['billing_city'],pf['billing_zip'],pf['billing_country'],pf['billing_state'],pf['billing_phone'],pf['billing_email'],pf['shipping_firstname'],pf['shipping_lastname'],pf['shipping_add1'],pf['shipping_add2'],pf['shipping_city'],pf['shipping_zip'],pf['shipping_country'],pf['shipping_state'],pf['shipping_phone'],pf['shipping_email'],pf['cardnumber'],pf['year'],pf['month'],pf['cardtype'],pf['cvv'],pf['cardholder'],pf['is_deleted'],pf['card_unique'])
                        update_tasks.append(UpdateTask(taskid,'Getting Information','#FFC300'))
                        #UpdateStatus(taskid,'Running','#FFC300')
                        if "kith" in web_domain:
                            Kith(tskss,pflss,)
                        elif "funko" in web_domain:
                            Funko(tskss,pflss,)
                        elif "figpin" in web_domain:
                            Funko(tskss,pflss,)
                        elif "bimtoy" in web_domain:
                            Funko(tskss,pflss,)
                        print("next")
                        break
            time.sleep(1)

        else:

            time.sleep(1)



if __name__ == '__main__':
    main()
