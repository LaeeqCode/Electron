config = {
  'user': 'worker',
  'password': 'LSaSCksa34Sxa',
  'host': 'www.popbot.org',
  'database': 'PopBot',
  'raise_on_warnings': True,
}