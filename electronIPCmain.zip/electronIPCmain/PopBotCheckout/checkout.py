import time
import mysql.connector
import sys

from PopBotCheckout.task import Task
from PopBotCheckout.profile import Profile
from PopBotCheckout.config import config
from PopBotCheckout.database import Database
import redis
import json
from PopBotCheckout.database import update_redis
from PopBotCheckout.database import get_task
from PopBotCheckout.sites.shopify import Shopify
#from PopBotCheckout.sites.boxlunch import BoxLunch
from PopBotCheckout.sites.htbl import HTBL
from PopBotCheckout.sites.disney import Disney
from PopBotCheckout.sites.walmart import Walmart
from PopBotCheckout.sites.bestbuy import BestBuy
from pyvirtualdisplay import Display

r = redis.StrictRedis(host='198.204.247.74', port=6379,db=0, charset="utf-8", decode_responses=True)
ss = sys.getdefaultencoding()
StopBot = False
db = Database(config)

tasks = []
profiles = []
update_tasks = []
update_tasks_title = []

def fetch_proxies_from_database(user_id):
    try:
        res_data = []
        connection = mysql.connector.connect(**config)
        connection.autocommit = True
        cursor = connection.cursor()
        sql="SELECT * from proxy where user_id=%s and is_deleted = 0;"
        cursor.execute(sql,('admin',))
        tsks=cursor.fetchall()
            #[{'ip': '54.33.23.11', 'password': '778', 'username': 'ffg', 'port': '50'}]
        for row in tsks:
            dt = {
                'id':row[0],
                'user_id':row[1],
                'ip': row[2],
                'port': row[3],
                'username': row[4],
                'password':row[5],
                'status':row[6],
                'is_deleted':row[7]
            }
            res_data.append(dt)
        cursor.close()
        connection.close()
        return res_data
    except:
        return []

def get_settings(user_id):
    res_data = []
    connection = mysql.connector.connect(**config)
    connection.autocommit = True
    cursor = connection.cursor()
    

    cursor.execute("SELECT  * from activations where user_id=%s " , (user_id,))
    usrs = cursor.fetchall()

    if len(usrs)>0:

        cursor.execute("SELECT  * from settings where user_id=%s" , (user_id,))
        tsks = cursor.fetchall()
        for row in tsks:
            dt = {
                'id':row[0],
                'user_id':row[1],
                'checkout_delay': row[2],
                'monitor_delay': row[3],
                'webhook_url':row[4],
                'is_deactivated':row[5],
                'refresh_ui':row[6]
            }
            res_data.append(dt)
        cursor.close()
        connection.close()
        return res_data[0]["webhook_url"]

def get_profiles():
    connection = mysql.connector.connect(**config)
    connection.autocommit = True
    cursor = connection.cursor()
    cursor.execute("SELECT  * from profile where is_deleted = 0 ")
    tmp_profiles = cursor.fetchall()

    new_profiles = list()

    for pf in tmp_profiles:
        new_profiles.append({
            "id": pf[0],
            "user_id": pf[1],
            "profile_name": pf[2],
            "billing_firstname": pf[3],
            "billing_lastname": pf[4],
            "billing_add1": pf[5],
            "billing_add2": pf[6],
            "billing_city": pf[7],
            "billing_zip": pf[8],
            "billing_country": pf[9],
            "billing_state": pf[10],
            "billing_phone": pf[11],
            "billing_email": pf[12],
            "shipping_firstname": pf[13],
            "shipping_lastname": pf[14],
            "shipping_add1": pf[15],
            "shipping_add2": pf[16],
            "shipping_city": pf[17],
            "shipping_zip": pf[18],
            "shipping_country": pf[19],
            "shipping_state": pf[20],
            "shipping_phone": pf[21],
            "shipping_email": pf[22],
            "cardnumber": pf[23],
            "year": pf[24],
            "month": pf[25],
            "cardtype": pf[26],
            "cvv": pf[27],
            "cardholder": pf[28],
            "is_deleted": pf[29],
            "card_unique": pf[30]
        })
    return new_profiles

def start_task(profileid,task,celery):
    # print(task)
    print("IN CHECKOUT START TASK")
    task = json.loads(task)
    print(task)
    profiles = get_profiles()
    web_domain = []
    web_domain.append(task["site_name"])
    print("web domainnnnnnn")
    print(web_domain)
    for pf in profiles:
#        print(pf)
        pfid = pf['id']
        if int(pfid) == int(profileid):
            #celery.update_state(state='Getting Information', meta={'status_color': '#FFC300'})
            update_redis(task,r,"Getting Information",'#FFC300')
            profile = Profile(pf['id'], pf['user_id'], pf['profile_name'], pf['billing_firstname'], pf['billing_lastname'], pf['billing_add1'], pf['billing_add2'], pf['billing_city'], pf['billing_zip'], pf['billing_country'], pf['billing_state'], pf['billing_phone'], pf['billing_email'], pf['shipping_firstname'], pf['shipping_lastname'], pf['shipping_add1'], pf['shipping_add2'], pf['shipping_city'], pf['shipping_zip'], pf['shipping_country'], pf['shipping_state'], pf['shipping_phone'], pf['shipping_email'], pf['cardnumber'], pf['year'], pf['month'], pf['cardtype'], pf['cvv'], pf['cardholder'], pf['is_deleted'], pf['card_unique'])
            #celery.update_state(state='Running', meta={'status_color': '#FFC300'})
            print(pf)
            print("Calling settings")

            try:
                w_url = get_settings(pf["user_id"])
            except:
                w_url = None
            print(w_url)
#            w_url = "https://discordapp.com/api/webhooks/720173980492890152/ARCAsRMLiD922ciQATjkzG_0kYpTvuhxEYX_wo_iNmlIT05_64rujbAryPieejzBInDm"

            update_redis(task,r,"Running",'#FFC300')
            display = Display(visible=0, size=(1024, 768))
            display.start()
            print("^^", web_domain)
            if "Kith" in web_domain:
                    print('In Kith. We do not support this website.')
                    pass
            elif "Funko" in web_domain:
                    print("funko in")
                    try:
                        site = Shopify(task, profile, celery,r, w_url, web_domain[0], base="checkout.funko.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                        site.checkout()
                    except:
                        pass
                    try:
                        site.browser.quit()
                    except:
                        pass
                    try:
                        del site
                    except:
                        pass
                    break
            elif "Box Lunch" in web_domain:
                    print("boxlunch in")
                    try:
                        site = HTBL(task, profile, celery,r, w_url, web_domain[0], is_ht=False, admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                        site.checkout()
                    except:
                        pass
                    try:
                        site.browser.quit()
                    except:
                        pass
                    try:
                        del site
                    except:
                        pass
                    break
            elif "Hot Topic" in web_domain:
                    print("hottopic in")
                    try:
                        site = HTBL(task, profile, celery,r, w_url, web_domain[0], admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                        site.checkout()
                    except:
                        pass
                    try:
                        site.browser.quit()
                    except:
                        pass
                    try:
                        del site
                    except:
                        pass
                    break
            elif "Disney" in web_domain:
                try:
                    site = Disney(task, profile, celery, r, w_url, web_domain[0], admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "Walmart" in web_domain:
                try:
                    site = Walmart(task, profile, celery, r, w_url, web_domain[0], admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "Abominable Toys" in web_domain:
                print("abominable")
                try:
                    site = Shopify(task, profile, celery, r, w_url, web_domain[0], base="abominabletoys.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "Bimtoy" in web_domain:
                try:
                    site = Shopify(task, profile, celery, r,w_url, web_domain[0], base="bimtoy.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "FiGPiN" in web_domain:
                try:
                    site = Shopify(task, profile, celery, r, w_url, web_domain[0],base="figpin.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "HasbroPulse" in web_domain:
                try:
                    site = Shopify(task, profile, celery, r,w_url, web_domain[0], base="hasbropulse.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "Loungefly" in web_domain:
                try:
                    site = Shopify(task, profile, celery, r,w_url, web_domain[0], base="loungefly.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "The Neca Store" in web_domain:
                try:
                    site = Shopify(task, profile, celery, r,w_url, web_domain[0], base="thenecastore.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "Bottle Neck Gallery" in web_domain:
                try:
                    site = Shopify(task, profile, celery, r, w_url, web_domain[0],base="bottleneckgallery.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "MartianToys" in web_domain:
                try:
                    site = Shopify(task, profile, celery, r, w_url, web_domain[0],base="martiantoys.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "TokTokyo" in web_domain:
                try:
                    site = Shopify(task, profile, celery, r,w_url, web_domain[0], base="launch.toytokyo.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "Plastic Empire" in web_domain:
                try:
                    site = Shopify(task, profile, celery, r,w_url, web_domain[0], base="plasticempire.com", admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            elif "Best Buy" in web_domain:
                try:
                    site = BestBuy(task, profile, celery, r,w_url, web_domain[0], admin_proxies=fetch_proxies_from_database(pf["user_id"]))
                    site.checkout()
                except:
                    pass
                try:
                    site.browser.quit()
                except:
                    pass
                try:
                    del site
                except:
                    pass
                break
            display.stop()

            

