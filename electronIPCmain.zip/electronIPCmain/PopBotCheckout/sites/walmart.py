from PopBotCheckout.sites.site import Site
import time
import requests
from bs4 import BeautifulSoup as soup
import threading
from PopBotCheckout.sites.test_config import *
import re
from PopBotCheckout.sites.utility import *
import urllib3
from PopBotCheckout.sites.getCaptcha import get_captcha
from selenium.webdriver.support.ui import Select
import json
from PopBotCheckout.database import update_title
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import random
import time
headersmain = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9,fr;q=0.8,es;q=0.7',
    'cache-control': 'max-age=0',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
    'referer': 'https://www.boxlunch.com/product/funko-pop-marvel-80th-anniversary-spider-man-vinyl-bobble-head/12499513.html',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin'
}

tries = 10
sleep_time = 0.5

class Walmart(Site):
    def __init__(self, task, profile, celery, r, webhook_url, web_domain, desktop=False, admin_proxies=[]):
        super(Walmart, self).__init__(task, profile, celery, r, webhook_url, web_domain,)
        self.browser_threads = []
        self.browser = None
        self.display = None
        self.session = requests.Session()
        self.desktop = desktop
        self.valid_browser = False
        self.restock = False
        self.using_proxy = False

        if not self.desktop:
            try:
                p = random.choice(self.proxy)
                if p not in admin_proxies:
                    self.using_proxy = True
                else:
                    print("Using Backend Proxies")
            except:
                p = None
            if p:
                self.ip = p["ip"]
                self.port = p["port"]
                self.username = p["username"]
                self.password = p["password"]
                self.proxy = "{}:{}:{}:{}".format(self.ip,self.port,self.username,self.password)
                print(self.proxy)
            else:
                self.proxy = None
        else:
            try:
                self.ip = self.proxy.split(":")[0]
                self.port = self.proxy.split(":")[1]
                self.username = self.proxy.split(":")[2]
                self.password = self.proxy.split(":")[3]
            except:
                pass

    def prod_search(self):
        match = '("offerId":")(.*)(,)'

        if "https:" in self.keyword_url or "http:" in self.keyword_url:
            if not self.restock:
                stop = self.msg("Adding by Link..", "#FFC300")
                if stop:
                    return "stop"
            s = requests.get(self.keyword_url, headers=headersmain)
            result = re.search(match, s.text)
            try:
                offerID = result.group(2).split('"')[0]
            except:
                offerID = False
            if '>Out of stock</span>'.lower() in s.text.lower():
                stop = self.msg("Waiting for Restock..", "#FFC300")
                self.restock = True
                if stop:
                    return "stop"
                return False
            return offerID
        else:
            words = self.keyword_url.split(" ")

            if len(words) == 1:
                if words[0][0] != "-" and words[0][0] != "+":
                    if not self.restock:
                        stop = self.msg("Adding by PID..", "#FFC300")
                        if stop:
                            return "stop"
                    s = requests.get("https://www.walmart.com/ip/Xbox-Series-X/{}".format(self.keyword_url), headers=headersmain)
                    result = re.search(match, s.text)
                    try:
                        offerID = result.group(2).split('"')[0]
                    except:
                        offerID = False
                    if '>Out of stock</span>'.lower() in s.text.lower():
                        stop = self.msg("Waiting for Restock..", "#FFC300")
                        self.restock = True
                        if stop:
                            return "stop"
                        return False
                    return offerID

            new_words = []
            for w in words:
                if w[0] == "-":
                    pass
                else:
                    new_words.append(w[1:])

            if not self.restock:
                stop = self.msg("Searching..", '#FFC300')
                if stop:
                    return "stop"

            base_url = "https://www.walmart.com/search/?query={}".format("%20".join(new_words))
            s = self.session_get(base_url, headers=headersmain)
            bs = soup(s.text, "html.parser")
            tiles = bs.find_all("a", {"class": "product-title-link"})

            for tile1 in tiles:
                title = tile1.get_text()
                link = tile1["href"]

                if verify_keywords(title, words):
                    if not self.restock:
                        stop = self.msg("Found product..", "#FFC300")
                        if stop:
                            return "stop"
                    s = self.session_get("https://www.walmart.com" + link, headers=headersmain)
                    result = re.search(match, s.text)
                    try:
                        offerID = result.group(2).split('"')[0]
                    except:
                        offerID = False
                    if '>Out of stock</span>'.lower() in s.text.lower():
                        stop = self.msg("Waiting for Restock..", "#FFC300")
                        self.restock = True
                        if stop:
                            return "stop"
                        return False
                    return offerID

            return None

    def browser_thread(self):
        try:
            if self.proxy:
                splits = self.proxy.split(":")
                self.browser = get_chromedriver(splits[0], splits[1], splits[2], splits[3], use_proxy=True, headless=(not self.desktop))
                #self.msg("Adding Proxy..", "#FFC300")
            else:
                self.browser = get_chromedriver("", "", "", "", use_proxy=False, headless=(not self.desktop))
            self.browser.get("https://www.walmart.com/asdfasdfasdf")

            while True:
                if "page you are looking for" in self.browser.page_source.lower():
                    self.browser_thread_complete = True
                    break
        except Exception as e:
            print(str(e))
            self.browser_thread_complete = True

    def checkout(self):
        try:
            if not self.verify_profile():
                self.msg("Incomplete Profile", '#FF0000')
                return

            self.browser_threads = []
            self.browser_threads.append(threading.Thread(target=self.browser_thread))
            self.browser_thread_started = True
            self.browser_thread_complete = False
            for thread in self.browser_threads:
                thread.start()

            offerID = False
            count = 0
            while not offerID:
                count += 1
                if count >= tries:
                    time.sleep(sleep_time)
                offerID = self.prod_search()
                if offerID:
                    if offerID.lower() == "stop":
                        self.stop()
                        return
                    if self.browser_thread_started and self.browser_thread_complete and self.browser is None:
                        self.browser_threads = []
                        self.browser_threads.append(threading.Thread(target=self.browser_thread))
                        self.browser_thread_started = True
                        self.browser_thread_complete = False
                        for thread in self.browser_threads:
                            thread.start()
                    break
                else:
                    if self.browser_thread_started and self.browser_thread_complete:
                        for thread in self.browser_threads:
                            thread.join()
                        self.stop()

            self.session = requests.session()
            if self.proxy:
                self.session.proxies = {"https": "https://{}".format("{}:{}@{}:{}".format(self.username, self.password, self.ip, self.port))}

            stop = self.msg("Adding to cart..", '#FFC300')
            if stop:
                self.stop()
                return

            countzz= 0
            while True:

                countzz += 1
                print("TRIES: {}".format(countzz))
                if countzz >= tries:
                    time.sleep(sleep_time)
                s = self.session_post("https://www.walmart.com/api/v3/cart/guest/:CID/items", headers={
                    "accept": "application/json",
                    "accept-encoding": "gzip, deflate, br",
                    "accept-language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
                    "content-type": "application/json",
                    "origin": "https://www.walmart.com",
                    "referer": self.keyword_url,
                    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.69 Safari/537.36"
                }, json={"offerId":offerID,"quantity":1, "location": {"postalCode": self.billing_zip, "state": self.billing_state, "isZipLocated": True, "city": self.billing_city}}, timeout=3)


                try:
                    print(s.text)
                    if "forbidden" in s.text.lower():
                        stop = self.msg("REQUEST BLOCKED", "#FF0000")
                        if stop:
                            self.stop()
                            return
                    data = json.loads(s.text)
                    the_title = data["items"][0]["name"]

                    self.product_title = the_title
                    break
                except Exception as e:
                    print_error_info(e)
                try:
                    update_title(self.task, self.r, the_title)
                except:
                    pass

            for thread in self.browser_threads:
                thread.join()

            for c in self.session.cookies:
                cook = {'name': c.name, 'value': c.value, 'path': c.path}
                self.browser.add_cookie(cook)
            self.msg("Getting Cookies..", '#FFC300')

            stop = self.msg("Going to checkout..", '#FFC300')
            if stop:
                self.stop()
                return
            self.browser.get("https://www.walmart.com/checkout/")

            clicked = False

            count1 = 0
            while True:
                count1 += 1
                if count1 >= tries:
                    time.sleep(sleep_time)
                try:
                    if not clicked:
                        self.browser.execute_script("document.querySelector('.SignUp-container .button--primary').click();")
                        clicked = True
                except:
                    pass

                try:
                    isButton = self.browser.execute_script("return document.querySelector('.CXO_fulfillment_continue .button-wrapper')")
                    if isButton:
                        self.browser.execute_script("document.querySelector('.CXO_fulfillment_continue .button-wrapper').click();")
                        break
                except Exception as e:
                    pass

            stop = self.msg("Submitting shipping..", '#FFC300')
            if stop:
                self.stop()
                return
            count2 = 0
            while True:
                count2 += 1
                if count2 >= tries:
                    time.sleep(sleep_time)
                isButton = self.browser.execute_script("return document.querySelector('input#firstName')")
                if isButton:
                    self.msg("Filling form..", '#FFC300')
                    set_and_verify(self.browser, "input#phone", self.billing_phone, ignores=["-", "(", ")"], send_keys=True, ya=True)

                    if len (self.billing_add2) > 0:
                        set_and_verify(self.browser, ["input#firstName", "input#lastName", "input#email", "input#addressLineOne", "input#addressLineTwo", "input#city", "input#postalCode"],
                                   [self.billing_firstname, self.billing_lastname, self.billing_email, self.billing_add1, self.billing_add2, self.billing_city, self.billing_zip], send_keys=True, lst=True)
                    else:
                        set_and_verify(self.browser, ["input#firstName", "input#lastName", "input#email", "input#addressLineOne", "input#city", "input#postalCode"],
                                       [self.billing_firstname, self.billing_lastname, self.billing_email, self.billing_add1, self.billing_city, self.billing_zip], send_keys=True, lst=True)

                    select = Select(self.browser.find_element_by_css_selector('select#state'))
                    select.select_by_value(self.billing_state)

                    input_zip = self.browser.find_element_by_css_selector("input#postalCode")
                    input_zip.send_keys(Keys.ENTER)
                    break

            stop = self.msg("Submitting billing..", '#FFC300')
            if stop:
                self.stop()
                return

            count3 = 0
            while True:
                count3 += 1
                if count3 >= tries:
                    time.sleep(sleep_time)
                self.msg("Filling form..", '#FFC300')
                isButton = self.browser.execute_script("return document.querySelector('div.address-validation-buttons button')")
                if isButton:
                    self.browser.execute_script("document.querySelector('div.address-validation-buttons button').click();")

                # isButton = self.browser.execute_script("return document.querySelector('div.address-validation-buttons button.use-address-validation')")
                # if isButton:
                #     self.browser.execute_script("document.querySelector('div.address-validation-buttons button.use-address-validation').click();")

                isButton = self.browser.execute_script("return document.querySelector('div.CXO_fulfillment_continue button')")
                if isButton:
                    self.browser.execute_script("document.querySelector('div.CXO_fulfillment_continue button').click();")

                isButton = self.browser.execute_script("return document.querySelector('input#creditCard')")
                if isButton:
                    set_and_verify(self.browser, "input#creditCard", self.cardnumber, send_keys=True, ya=True)
                    set_and_verify(self.browser, "select#month-chooser", self.expmonth, send_keys=True)

                    try:
                        select = Select(self.browser.find_element_by_css_selector('select#year-chooser'))
                        select.select_by_value(self.expyear)
                    except Exception as e:
                        pass
                    card = self.browser.find_element_by_css_selector("input#cvv")
                    card.send_keys(self.cardcvv)
                    card.send_keys(Keys.ENTER)
                    print("entered info")
#                    self.stop()
                    break

            breakout = False
            quit_now = False
            count4 = 0
            while breakout is False:
                count4 += 1
                if count4 >= tries:
                    time.sleep(sleep_time)
                captcha = False
                count5 = 0
                while True:
                    count5 += 1
                    if count5 >= tries:
                        time.sleep(sleep_time)
                    try:
                        isButton = self.browser.execute_script("return document.querySelector('div.place-order button.button')")
                        if isButton:
                            self.browser.execute_script("document.querySelector('div.place-order button.button').click();")

                            break

                        if "help us keep your account safe by" in self.browser.page_source.lower() or "help us keep your information safe by" in self.browser.page_source.lower():
                            captcha = False

                            break
                        if "enter a valid credit card number.</span" in self.browser.page_source.lower():

                            quit_now = True
                            break
                    except Exception as e:
                        pass

                if quit_now:
                    break

                if not captcha:
                    breakout = True
                    continue



            stop = self.msg("Checkout completed..", '#FFC300')
            if stop:
                self.stop()
                return

            curr_title = self.browser.title.lower()
            count8 = 0
            once = False
            cntt = 0
            cntt2 = 0
            resp = None
            while True:
                count8 += 1
                cntt += 1
                if count8 >= tries:
                    time.sleep(sleep_time)
                    send_screenshot(self.browser, "")

                if resp is None:
                    pass
                else:
                    self.browser.execute_script('document.getElementById("g-recaptcha-response").innerHTML = "%s"' % resp)
                    self.browser.execute_script('handleCaptcha("{}");'.format(resp))


                if (("help us keep your account safe by" in self.browser.page_source.lower() or "help us keep your information safe by" in self.browser.page_source.lower())):
                    if cntt >= 25 or once is False:
                        captcha = True
                        once = True
                        if cntt >= 25:

                            cntt = 0

                solved_captcha = False
                count6 = 0
                while captcha:
                    count6 += 1
                    if count6 >= tries:
                        time.sleep(sleep_time)
                    stop = self.msg("Solving Captcha..", '#FFC300')
                    if stop:
                        self.stop()
                        return
                    if captcha:
                        try:
                            resp = get_captcha(self.browser, proxy=[self.username, self.password, self.ip, self.port])
                        except Exception as e:
                            print(str(e))
                        print("resp: {}".format(resp))

                        print("injecting response")
                        try:
                            isButton = self.browser.execute_script('return document.getElementById("g-recaptcha-response")')
                            if isButton:
                                print("THE THING EXISTS")
                            self.browser.execute_script('document.getElementById("g-recaptcha-response").innerHTML = "%s"' % resp)
                            self.browser.execute_script('handleCaptcha("{}");'.format(resp))


                            captcha = False
                            solved_captcha = True
                        except Exception as e:
                            print(str(e))
                if solved_captcha:
                    stop = self.msg("Captcha Solved..", '#FFC300')
                    if stop:
                        self.stop()
                        return

                    count7 = 0
                    while True:
                        count7 += 1
                        if count7 >= tries:
                            time.sleep(sleep_time)
                        card = self.browser.find_element_by_css_selector("input#cvv")
                        card.send_keys(self.cardcvv)
                        card.send_keys(Keys.ENTER)
                        breakout = True
                        break




                new_title = self.browser.title.lower()

                if quit_now:
                    self.msg("Invalid Card Info", '#FF0000')
                    break

                try:
                    card = self.browser.find_element_by_css_selector("input#cvv")
                    card.send_keys(self.cardcvv)
                    card.send_keys(Keys.ENTER)
                except:
                    pass

                try:
                    self.browser.execute_script("document.querySelector('button.auto-submit-place-order')")

                    self.browser.execute_script("document.querySelector('button.auto-submit-place-order')")


                    self.browser.execute_script("document.querySelector('button.auto-submit-place-order').click()")
                except:
                    pass


                if "your payment couldn't be authorized" in self.browser.page_source.lower():
                    self.msg("Card Declined", '#FF0000')
                    break

                if new_title != curr_title and "choose payment method" not in new_title and "choose payment method" not in new_title:
                    cntt2 += 1
                    if cntt2 > 30:
                        self.msg("Successful Checkout", '#00FF00')
                        break
            self.stop()
        except Exception as e:
            print(str(e))
            self.stop()

if __name__ == "__main__":
    desktop = True
    walmart = Walmart(task, prof, None, None, "https://google.com", "https://google.com", desktop=True)
    walmart.checkout()