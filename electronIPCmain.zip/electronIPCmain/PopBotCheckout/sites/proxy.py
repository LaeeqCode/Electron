import requests
import random
import mysql.connector

config = {
  'user': 'root',
  'password': 'LJtB15ar6xT0',
  'host': '127.0.0.1',
  'database': 'PopBot',
  'raise_on_warnings': True,
    }

def getProxies(self):
    myProxies=self.task['proxy']
    px_list=[]
    if myProxies is not None:
        # We have initialized the task object with proxies while creating the task
        for row in myProxies:
        	if row['status'] == "dead":
        		continue
        	else:
	            proxyRow = "http://" + row['username'] + ':' + row['password'] + '@' + row['ip'] + ':' + row['port']
	            pd={
	            'id' : row['id'],
	            'proxy' : proxyRow
	            }
	            px_list.append(pd)
        return px_list
    return myProxies



def createSession(self,pxs):
    thisSession=requests.Session()
    proxyList=[]
    id=None
    if pxs is None:
        return thisSession
    for row in pxs:
        proxyList.append(row['proxy'])
    try:
        pxy=random.choice(proxyList)
        px_dict = {
             'http' : pxy
             }                     
        thisSession.proxies = px_dict
        thisSession = thisSession.get("http://ipinfo.io")
    except:
        for row in pxs:
            if row['proxy']==pxy:
                id=row['id']
                connection = mysql.connector.connect(**config)
                connection.autocommit = True
                cursor = connection.cursor()
                sql="update proxy set status=%s where id = %s"
                s="dead"
                cursor.execute(sql, (s,id))
                cursor.close()
                connection.close()
                pxs.remove(row)
        if len(pxs) > 0:
            createSession()
        elif len(pxs) == 0:
            thisSession=requests.Session()
    return thisSession