import requests
from bs4 import BeautifulSoup as soup
print("in c")
headersmain = {
    'accept': '*/*',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    #'cache-control': 'max-age=0',
    #'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
    'origin': 'https://www.shopdisney.com',
    'referer': 'https://www.shopdisney.com/chip-mug-beauty-and-the-beast-400020128157.html?isProductSearch=1&plpPosition=2&searchType=regular',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',

}
print("IN HERE")

words = "+funko"

if len(words) == 1:

    if words[0][0] != "-" and words[0][0] != "+":
        if not self.restock:
            stop = self.msg("Adding by PID..", "#FFC300")
            if stop:
                return "stop"
        return "-" + str(words[0]) + ".html"

new_words = []
print("NEW WORDS")
for w in words:
    if w[0] == "-":
        pass
    else:
        new_words.append(w)
        print(new_words)


print("MAKING REQ")
base_url = "https://www.shopdisney.com/search?q={}".format("+".join(new_words))
s = self.session_get(base_url, headers=headersmain)
bs = soup(s.text, "html.parser")
tiles = bs.find_all("a", {"class": "product__tile_link"})
for tile1 in tiles:
    title = tile1.get_text()
    link = tile1["href"]
    print("TITLE")
    print(link)

    if verify_keywords(title, words):
        if not self.restock:
            stop = self.msg("Found product..", "#FFC300")
            if stop:
                return "stop"
        return link