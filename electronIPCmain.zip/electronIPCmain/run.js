let btn = document.querySelector('#btn')
const { ipcRenderer } = require('electron')

btn.addEventListener("click", checkout);

function checkout() {
  const { ipcRenderer } = require('electron')

  ipcRenderer.send('checkout-call', 'Calling checkout from renderer')
}

ipcRenderer.on('checkout-reply', (event, arg) => {
  console.log("Checkout reply from renderer") // prints "pong"
  console.log(arg)
  })


btn.dispatchEvent(new Event('click'))






