const { PythonShell } = require('python-shell')

function run_py() {
    let pyshell = new PythonShell('run.py')
    pyshell.on('message', function (message) {
        console.log(message)
    })
    pyshell.end(function (err, code, signal) {
        if (err) throw err;
        console.log(code + ' ' + signal);
    })
}