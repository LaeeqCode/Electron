class Task:
    def __init__(self, id, user_id, site,profile, profile_id, keyword_url, size, timer, quantity, number_tasks, is_deleted, status,is_captcha,status_color,createdat,site_name,one_checkout,status_title, proxy,title):
        self.id = id
        self.user_id = user_id
        self.site = site
        self.profile = profile
        self.profile_id = profile_id
        self.keyword_url = keyword_url
        self.size = size
        self.timer = timer
        self.quantity = quantity
        self.number_tasks = number_tasks
        self.is_deleted = is_deleted
        self.status = status
        self.is_captcha = is_captcha
        self.status_color = status_color
        self.createdat = createdat
        self.site_name = site_name
        self.one_checkout = one_checkout
        self.status_title = status_title
        self.proxy = proxy
        self.title=title