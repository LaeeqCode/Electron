class Card():
    def __init__(self, cardnumber, month, year, cvv):
        self.cardnumber = cardnumber
        self.month = month
        self.year = year
        self.cvv = cvv