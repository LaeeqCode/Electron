import mysql.connector
import json
from collections import namedtuple

class Database:
    def __init__(self, config):
        self.config = config

    def update_task(self, task_id, status, clor):
        connection = mysql.connector.connect(**self.config)
        cursor = connection.cursor()
        cursor.execute("UPDATE task SET status=%s , status_color=%s WHERE id = %s",(status, clor, task_id))
        connection.commit()
        cursor.close()
        connection.close()


def update_redis(task,r,status, status_color):
    user_id = task['user_id']
    task_id = task['id']
    tasks=r.hget(user_id,task_id)
    tasks=json.loads(tasks)
    tasks["status"]=status
    tasks["status_color"]=status_color
    r.hdel(user_id,task_id)
    tasks=json.dumps(tasks)
    r.hset(user_id,task_id,tasks)


def get_task(task, r):
    user_id = task['user_id']
    task_id = task['id']
    tasks=None
    tasks = r.hget(user_id,task_id)
    tasks=json.loads(tasks)
    if tasks!=None:
        return tasks


def update_title(task,r,title):
    user_id = task['user_id']
    task_id = task['id']
    tasks = r.hget(user_id,task_id)
    tasks=json.loads(tasks)
    tasks["title"]=title
    r.hdel(user_id,task_id)
    tasks=json.dumps(tasks)
    r.hset(user_id,task_id,tasks)

