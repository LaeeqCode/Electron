
from PopBotCheckout.database import update_title
from PopBotCheckout.sites.site import Site
import requests
import json
from bs4 import BeautifulSoup as soup
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from PopBotCheckout.sites.utility import *
from PopBotCheckout.sites.test_config import *
import re
from PopBotCheckout.sites.getCaptcha import get_captcha
import time
import random
import threading
from requests.auth import HTTPProxyAuth

tries = 10
sleep_time = 0.5

class Shopify(Site):
    def __init__(self, task, profile, celery, r, webhook_url, web_domain, desktop=False, base="abominabletoys.com", admin_proxies=[]):
        super(Shopify, self).__init__(task, profile, celery, r, webhook_url, web_domain)
        self.base = base
        self.searching = 1
        self.desktop = desktop
        self.restock = False

        self.browser_threads = []
        self.browser = None
        self.valid_browser = False

        self.browser_thread_started = False

        self.using_proxy = False

        print("PROXY: {}".format(self.proxy))

        if not self.desktop:
            try:
                p = random.choice(self.proxy)
                if p not in admin_proxies:
                    self.using_proxy = True
                else:
                    print("Using Backend Proxies")
            except:
                p = None
            if p:
                self.ip = p["ip"]
                self.port = p["port"]
                self.username = p["username"]
                self.password = p["password"]
                self.proxy = "{}:{}:{}:{}".format(self.ip,self.port,self.username,self.password)
            else:
                self.proxy = None
        else:
            try:
                self.ip = self.proxy.split(":")[0]
                self.port = self.proxy.split(":")[1]
                self.username = self.proxy.split(":")[2]
                self.password = self.proxy.split(":")[3]
            except:
                pass
        #print("***")
       # print(admin_proxies)
        #time.sleep(900)

    def browser_thread(self):
        try:
            if self.proxy:
                splits = self.proxy.split(":")
                self.browser = get_chromedriver(splits[0], splits[1], splits[2], splits[3], use_proxy=True, headless=(not self.desktop))
                self.msg("Adding Proxy..", "#FFC300")
            else:
                self.browser = get_chromedriver("", "", "", "", use_proxy=False, headless=(not self.desktop))
            self.browser.get("https://{}".format(self.base))

            while True:
                if len(self.browser.page_source.lower()) > 0:
                    self.browser_thread_complete = True
                    break
        except Exception as e:
            print(str(e))
            self.browser_thread_complete = True

    def product_search_atc(self, keywords):
        try:
            productFound = False
            count = 0
            while productFound == False:
                count += 1
                if count >= tries:
                    time.sleep(sleep_time)
                c = 0
                while True:
                    c += 1
                    link = 'http://{}/products.json?limit=250&page={}'.format(self.base, c)
                    words = self.keyword_url.lower().split(" ")

                    if len(words) == 1:
                        if words[0][0] != "-" and words[0][0] != "+":
                            stop = self.msg("Adding by PID..", "#FFC300")
                            if stop:
                                return "stop"
                            return str(words[0])
                    print(link)
                    r = self.session_get(link)
                    #print(r.text)
                    try:
                        data = json.loads(r.text)
                    except:
                        text_file = open("Output.txt", "w")
                        text_file.write("Purchase Amount: %s" % r.text)
                        text_file.close()
                        pass
                    new_words = []
                    for w in words:
                        if w[0] == "-":
                            pass
                        else:
                            new_words.append(w)

                    if len(data["products"]) <= 0:
                        break

                    for product in data["products"]:
                        title = product["title"]
                        sku = product["variants"][0]["sku"]
                        print(title)
                        variants = product["variants"]
                        if verify_keywords(title.lower(), words):
                            return variants[0]["id"]
                        if verify_keywords(sku.lower(), words):
                            return variants[0]["id"]
                return False
        except Exception as e:
            print_error_info(e)

    def add_to_cart(self, session):
        try:
            variant = None

            added = False
            count2 = 0
            while added is False:
                count2 += 1
                if count2 >= tries:
                    time.sleep(sleep_time)
                if not self.restock:
                    stop = self.msg("Searching..[{}]".format(self.searching), "#FFC300")
                    if stop:
                        return "stop"

                if not variant:
                    if 'http' not in self.keyword_url:
                        variant = self.product_search_atc(self.keyword_url)
                        if "stop" in str(variant):
                            return "stop"
                    else:
                        if "funko.com" not in self.keyword_url:
                            stop = self.msg("Adding by Link..", "#FFC300")
                            if stop:
                                return "stop"
                            matcher = '("variants":\[{"id":)(.*)'
                            s = self.session_get(self.keyword_url)
                            result = re.search(matcher, s.text)
                            offerID = result.group(2).split(',')[0]
                            variant = offerID
                        else:
                            stop = self.msg("Adding by Link..", "#FFC300")
                            if stop:
                                return "stop"
                            if self.browser is None and self.browser_thread_started is False:
                                self.browser_threads = []
                                self.browser_threads.append(threading.Thread(target=self.browser_thread))
                                self.browser_thread_complete = False
                                self.browser_thread_started = True
                                for thread in self.browser_threads:
                                    thread.start()
                                for thread in self.browser_threads:
                                    thread.join()
                                self.browser.get(self.keyword_url)

                            try:
                                #i_num = self.browser.execute_script('return document.querySelector("div.commerce-product-data-points div")').get_text()

                                pattern = '(retailer_item_id" content=\")(.*)'
                                result = re.search(pattern, self.browser.page_source)
                                number = result.group(2).split('"')[0]
                                if len(number) > 1:
                                    self.keyword_url = "+{}".format(number)
                                    print("num is " + number)
                                    variant = self.product_search_atc(session, self.keyword_url)
                                    self.stop()
                                    self.browser_thread_started = False
                                else:
                                    variant = None



                            except Exception as e:
                                print("..." + str(e))
                                variant = None
                                pass



                if not variant:
                    self.searching += 1
                    continue

                else:
                    link = "https://{}/cart/add.js?quantity=1&id=".format(self.base) + str(variant)
                    response = self.session_get(link)
                    addToCartData = json.loads(response.text)
                    try:
                        the_title = addToCartData["product_title"]
                        self.product_title = the_title
                        update_title(self.task, self.r, the_title)
                    except:
                        pass
                    try:
                        try:
                            added = addToCartData["quantity"]
                        except:
                            added = 0
                        if added >= 1:
                            stop = self.msg("Added to Cart..", "#FFC300")
                            if stop:
                                return "stop"
                            return response
                        else:
                            stop = self.msg("Waiting for Restock..", "#FFC300")
                            if stop:
                                return "stop"
                    except Exception as e:
                        print(str(e))
                        pass
                    self.searching += 1
        except Exception as e:
            #print_error_info(e)
            print("add_to_cart: " + str(e))
            print_error_info(e)
            return str(e)

    def checkout(self):
        if not self.verify_profile():
            self.msg("Incomplete Profile", '#FF0000')
            return
        if self.billing_country == "US":
            self.billing_country = "United States"
        try:
            if self.proxy:
                prx = "{}:{}@{}:{}".format(self.username, self.password, self.ip, self.port)
                self.session.proxies = {"https": "https://{}".format(prx)}

                self.msg("Adding Proxy..", "#FFC300")
                print(prx)
                #time.sleep(900)
            while True:
                try:
                    print("ATC")
                    stop = self.add_to_cart(self.session)
                    if stop == "stop":
                        self.stop()
                        return

                    print("TMP")
                    tempLink = "http://{}/checkout.json".format(self.base)
                    response = self.session_get(tempLink, allow_redirects=True)
                    print("GOTTEN")

                    bs = soup(response.text, "html.parser")
                    authToken = bs.find('input', {"name": "authenticity_token"})['value']
                    checkout = response.url
                    break
                except Exception as e:
                    print("Checkout: " + str(e))

            count3 = 0
            while True:
                count3 += 1
                if count3 >= tries:
                    time.sleep(sleep_time)
                if 'stock_problems' in checkout:
                    stop = self.msg("Waiting for Restock..", "#FFC300")
                    if stop:
                        self.stop()
                        return
                    response = self.session_get(tempLink, allow_redirects=True)
                else:
                    break

            cookies = self.session.cookies.get_dict()

            count4 = 0
            while True:
                count4 += 1
                if count4 >= tries:
                    time.sleep(sleep_time)
                if 'queue' in checkout:
                    pass
                else:
                    stop = self.msg("Passed Queue", "#FFC300")
                    if stop:
                        self.stop()
                        return
                    break

            headers = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36'
            }

            payload1 = {
                "utf8": u'\u2713',
                "_method": "patch",
                "authenticity_token": authToken,
                "previous_step": "contact_information",
                "step": "shipping_method",
                "checkout[email]": self.billing_email,
                "checkout[buyer_accepts_marketing]": "1",
                "checkout[shipping_address][first_name]": self.billing_firstname,
                "checkout[shipping_address][last_name]": self.billing_lastname,
                "checkout[shipping_address][address1]": self.billing_add1,
                "checkout[shipping_address][address2]": self.billing_add2,
                "checkout[shipping_address][city]": self.billing_city,
                "checkout[shipping_address][country]": self.billing_country,
                "checkout[shipping_address][province]": self.billing_state,
                "checkout[shipping_address][zip]": self.billing_zip,
                "checkout[shipping_address][phone]": self.billing_phone,
                "checkout[remember_me]": "0",
                "checkout[client_details][browser_width]": "1710",
                "checkout[client_details][browser_height]": "1289",
                "checkout[client_details][javascript_enabled]": "1",
                "button": ""
            }

            captchaPresent = bs.find("div", {"id": "g-recaptcha"})
            site_key = ""
            if captchaPresent:
                matching = '(sitekey: ")(.*)(,)'
                result = re.search(matching, response.text)
                site_key = result.group(2).split('"')[0]

            count5 = 0
            while True:
                count5 += 1
                if count5 >= tries:
                    time.sleep(sleep_time)
                s = self.session_post(checkout, cookies=cookies, data=payload1, headers=headers)
                captcha_failed = False

                if s.status_code is 200 and not captcha_failed:
                    stop = self.msg("Going to Checkout..", "#FFC300")
                    if stop:
                        self.stop()
                        return
                    break
                else:
                    print(s.status_code)
                    stop = self.msg("Shipping Error", "#FF0000")
                    if stop:
                        self.stop()
                        return

            shipmentOptionLink = "http://{}".format(self.base) + "//cart/shipping_rates.json?shipping_address[zip]=" + self.billing_zip + \
                                 "&shipping_address[country]=" + self.billing_country + "&shipping_address[province]=" + self.billing_state
            shipmentOptionLink = shipmentOptionLink.replace(' ', '%20')

            r = self.session_get(shipmentOptionLink, cookies=cookies)
            shipping_options = json.loads(r.text)
            shipping_option = None

            try:
                print(shipping_options)
                ship_opt = shipping_options["shipping_rates"][0]["code"]
                tsource = shipping_options["shipping_rates"][0]["source"]
                ship_prc = shipping_options["shipping_rates"][0]["price"]
                shipping_option = tsource + "-" + ship_opt + "-" + ship_prc
                shipping_option = shipping_option.replace(" ", "%20")
                print(shipping_option)
                shipping_op = shipping_option
            except KeyError:
                self.msg("Bad Shipping Token", "#FF0000")

            headers = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36',
            }

            payload2 = {
                "_method": "patch",
                "authenticity_token": authToken,
                "previous_step": "shipping_method",
                "step": "payment_method",
                "checkout[shipping_rate][id]": shipping_op,
                "button": ""
            }

            count6 = 0
            while True:
                count6 += 1
                if count6 >= tries:
                    time.sleep(sleep_time)
                r = self.session_post(checkout, data=payload2, cookies=cookies, headers=headers)
                print(checkout)
                if "payment_method" in r.url:
                    print("SUCCESS SHIPPING!")
                    break

                if r.status_code is 200 and "error - information" not in r.text.lower():
                    stop = self.msg("Shipping Submitted..", "#FFC300")
                    if stop:
                        self.stop()
                        return
                    break
                else:
                    stop = self.msg("Shipping Error..", "#FFC300")
                    if stop:
                        self.stop()
                        return

            link = checkout + '?step=payment_method'
            r = self.session_get(link, cookies=cookies)
            bs = soup(r.text, "html.parser")
            div = bs.find("div", {"class": "radio__input"})
            gateway = ""
            values = str(div.input).split('"')
            for value in values:
                if value.isnumeric():
                    gateway = value
                    break

            bs = soup(r.text, "html.parser")
            totalPrice = bs.find('input', {'name': 'checkout[total_price]'})['value']

            stop = self.msg("Submitting Billing..", "#FFC300")
            if stop:
                self.stop()
                return
            link = "https://elb.deposit.shopifycs.com/sessions"

            payload3 = {
                "credit_card": {
                    "number": self.cardnumber,
                    "name": self.cardname,
                    "month": self.expmonth,
                    "year": self.expyear[2:],
                    "verification_value": self.cardcvv
                }
            }

            while True:
                try:
                    r = self.session_post(link, json=payload3)
                    break
                except:
                    pass
            payment_token = json.loads(r.text)["id"]

            headers = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36'
            }

            resp = ""
            if captchaPresent:
                stop = self.msg("Solving Captcha..", '#FFC300')
                if stop:
                    self.stop()
                    return
                resp = get_captcha(None, url="https://" + self.base, site_key=site_key)

            payload4 = {
                 "utf8": u'\u2713',
                 "_method": "patch",
                 "authenticity_token": authToken,
                 "previous_step": "payment_method",
                 "step": "",
                 'checkout[buyer_accepts_marketing]': '1',
                 "s": payment_token,
                 "checkout[payment_gateway]": gateway,
                 "checkout[different_billing_address]": "false",
                 'checkout[credit_card][vault]': 'false',
                 'checkout[total_price]': totalPrice,
                 "complete": "1",
                 "checkout[client_details][browser_width]": '978',
                 "checkout[client_details][browser_height]": '622',
                 "checkout[client_details][javascript_enabled]": "1",
                 "g-recaptcha-response": resp,
                 "button": ""
            }

            r = self.session_post(checkout, cookies=cookies, headers=headers, data=payload4)

            if r.status_code == 200 and "error - shipping" not in r.text.lower():
                self.msg("Successful Checkout?", "#00FF00")
            if r.status_code == 404 or "error - shipping" in r.text.lower():
                self.msg("Card Declined", "#FF0000")
            self.stop()

        except Exception as e:
            if "parse" in str(e):
                self.msg("Bad Proxy", '#FF0000')
            print(str(e))
            print_error_info(e)

if __name__ == "__main__":
    shopify = Shopify(task, prof, None, None, "https://discordapp.com/api/webhooks/720173980492890152/ARCAsRMLiD922ciQATjkzG_0kYpTvuhxEYX_wo_iNmlIT05_64rujbAryPieejzBInDm", "Funko", desktop=True, base="checkout.funko.com")
    shopify.checkout()
