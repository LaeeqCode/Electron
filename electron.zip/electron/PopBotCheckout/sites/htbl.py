from PopBotCheckout.sites.site import Site
import requests
import re
from bs4 import BeautifulSoup as soup
import threading
from selenium.webdriver.common.action_chains import ActionChains
from PopBotCheckout.sites.test_config import *
from PopBotCheckout.sites.utility import *
import urllib3
from PopBotCheckout.database import update_title
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import random
import time
headersmain = {
    'accept': '*/*',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin'
}

tries = 10
sleep_time = 0.5

class HTBL(Site):
    def __init__(self, task, profile, celery, r, webhook_url, web_domain, desktop=False, is_ht=True, admin_proxies=[]):
        super(HTBL, self).__init__(task, profile, celery, r, webhook_url, web_domain)
        self.browser_threads = []
        self.desktop = desktop
        self.restock = False
        self.bad_proxy = False
        self.lets_restart = False
        self.using_proxy = False
        if is_ht:
            self.base = "hottopic"
        else:
            self.base = "boxlunch"
        headersmain['referer'] = 'https://www.{}.com'.format(self.base)
        print(self.proxy)
        if not self.desktop:
            try:
                p = random.choice(self.proxy)
                if p not in admin_proxies:
                    self.using_proxy = True
                else:
                    print("Using Backend Proxies")
            except:
                p = None
            if p:
                self.ip = p["ip"]
                self.port = p["port"]
                self.username = p["username"]
                self.password = p["password"]
                self.proxy = "{}:{}:{}:{}".format(self.ip,self.port,self.username,self.password)
            else:
                self.proxy = None
        else:
            try:
                self.ip = self.proxy.split(":")[0]
                self.port = self.proxy.split(":")[1]
                self.username = self.proxy.split(":")[2]
                self.password = self.proxy.split(":")[3]
            except:
                pass

    def prod_search(self):
        if "https:" in self.keyword_url or "http:" in self.keyword_url:
            s = requests.get(self.keyword_url, headers=headersmain)
            bs = soup(s.text, "html.parser")
            product_id = bs.find("span", {"itemprop": "productID"}).get_text()
            if not self.restock:
                stop = self.msg("Adding by Link..", "#FFC300")
                if stop:
                    return "stop"
            return product_id
        else:
            words = self.keyword_url.split(" ")

            if len(words) == 1:
                if words[0][0] != "-" and words[0][0] != "+":
                    if not self.restock:
                        stop = self.msg("Adding by PID..", "#FFC300")
                        if stop:
                            return "stop"
                    return str(words[0])

            new_words = []
            for w in words:
                if w[0] == "-":
                    pass
                else:
                    new_words.append(w)

            if not self.restock:
                stop = self.msg("Searching..", '#FFC300')
                if stop:
                    return "stop"

            base_url = "https://www.{}.com/search?q={}".format(self.base, "+".join(new_words))

            s = self.session_get(base_url, headers=headersmain)
            bs = soup(s.text, "html.parser")
            tiles = bs.find_all("li", {"class": "grid-tile"})

            try:
                if "stop" in s:
                    return "stop"
            except:
                pass

            for tile1 in tiles:
                title = tile1.find("a", {"class": "name-link"})["title"]
                print(title)
                link = tile1.find("a", {"class": "name-link"})["href"]

                if verify_keywords(title, words):
                    if not self.restock:
                        stop = self.msg("Found product..", "#FFC300")
                        if stop:
                            return "stop"
                    s = requests.get(link, headers=headersmain)
                    bs = soup(s.text, "html.parser")
                    product_id = bs.find("span", {"itemprop": "productID"}).get_text()
                    return product_id
            return None

    def browser_thread(self):
        try:
            if self.proxy:
                splits = self.proxy.split(":")
                self.browser = get_chromedriver(splits[0], splits[1], splits[2], splits[3], use_proxy=True, headless=(not self.desktop))
            else:
                self.browser = get_chromedriver("", "", "", "", use_proxy=False, headless=(not self.desktop))
            self.browser.get("https://www.{}.com/asdfsdf".format(self.base))

            count = 0
            while True:
                count += 1
                if count >= tries:
                    time.sleep(sleep_time)
                if "invalid url" in self.browser.page_source.lower():
                    self.browser_thread_complete = True
                    break
                elif "<html><head></head><body></body></html>" in self.browser.page_source.lower():
                    count += 1
                    if count >= 40:
                        self.browser_thread_complete = True
                        print("Blank Page..")
                        self.bad_proxy = True
                        break
                elif "something wrong with the proxy server" in self.browser.page_source.lower() or "didn't send any data" in self.browser.page_source.lower():

                    print("No Internet.. Trying again ..")
                    self.stop()
                    self.bad_proxy = True
                    self.browser_thread_complete = True
                    break

        except Exception as e:
            print(str(e))
            self.browser_thread_complete = True

    def checkout(self):
        if not self.verify_profile():
            self.msg("Incomplete Profile", '#FFC300')
            return

        if self.proxy:
            self.session.proxies = {"https": "https://{}".format("{}:{}@{}:{}".format(self.username, self.password, self.ip, self.port))}

        try:
            self.browser_threads = []
            self.browser_threads.append(threading.Thread(target=self.browser_thread))
            self.browser_thread_started = True
            self.browser_thread_complete = False
            for thread in self.browser_threads:
                thread.start()

            count = 0
            while True:
                count += 1
                if count >= tries:
                    time.sleep(sleep_time)
                found = False
                count2 = 0
                while not found:
                    count2 += 1
                    if count2 >= tries:
                        time.sleep(sleep_time)
                    found = self.prod_search()
                    if found == "stop":
                        print("stopping")
                        self.stop()
                        return
                    if found:
                        if self.browser_thread_started and self.browser_thread_complete and self.browser is None and not self.restock:
                            self.browser_threads = []
                            self.browser_threads.append(threading.Thread(target=self.browser_thread))
                            self.browser_thread_started = True
                            self.browser_thread_complete = False
                            for thread in self.browser_threads:
                                thread.start()
                    else:
                        if self.browser_thread_started and self.browser_thread_complete and not self.restock:
                            for thread in self.browser_threads:
                                thread.join()
                            self.stop()
                if found:
                    item_id = found

                info_url = "https://www.{}.com/on/demandware.store/Sites-{}-Site/default/Product-Variation?pid={}&dwvar_{}_color=&dwvar_{}_size=&dwvar_{}_inseam=&dwvar_{}_dresslength=&dwvar_{}_cupsize=&dwvar_{}_calfwidth=&Quantity=1&format=ajax&Quantity=1&format=ajax".format(self.base, self.base, item_id, item_id, item_id, item_id, item_id, item_id, item_id)

                print(info_url)

                s = self.session_get(info_url, headers=headersmain)

                my_soup = soup(s.text, "html.parser")
                shippingMethod = my_soup.find("input", {"class": "ship-home-{}".format(item_id)}).attrs["value"]
                #storeId = my_soup.find("div", {"class": "delivery-option"}).attrs["data-storeid-{}".format(item_id)]
                deliveryMsgHome = my_soup.find("input", {"id": "deliveryMsgHome-{}".format(item_id)}).attrs["value"]

                if "presale" in s.text.lower():
                    deliveryMsg = "Presale"
                else:
                    deliveryMsg = "Delivered to Stores in 3 - 8 Business Days"

                my_data = {
                    "Quantity": "1",
                    "cgid": "",
                    "uuid": "",
                    "cartAction": "update",
                    "pid": item_id,
                    "shippingMethod-{}".format(item_id): shippingMethod,
                    #"atc-{}".format(item_id): "0.0",
                    #"storeId-{}".format(item_id): storeId,
                    "deliveryMsgHome-{}".format(item_id): deliveryMsgHome,
                    #"deliveryType-{}".format(item_id): "STS",
                    #"deliveryMsg-{}".format(item_id): deliveryMsg
                }
                atc_url = 'https://www.{}.com/on/demandware.store/Sites-{}-Site/default/Cart-AddProduct?format=ajax'.format(self.base, self.base)
                s = self.session_post(atc_url, headers={**headersmain, "content-type": "application/x-www-form-urlencoded; charset=UTF-8"}, data=my_data)
                cookies = s.cookies.get_dict()

                s = self.session_get("https://www.{}.com/checkout".format(self.base), headers=headersmain, cookies=cookies)
                cookies = s.cookies.get_dict()
                if not self.restock:
                    self.msg("Getting cookies..", '#FFC300')

                exp="(dwcont=)([a-zA-Z0-9]*)"
                dwcont = re.search(exp, s.text, flags=0).group(2)

                cart_url = "https://www.{}.com/checkout?dwcont={}".format(self.base, dwcont)

                if not self.restock:
                    stop = self.msg("Adding to cart..", '#FFC300')
                    if stop:
                        self.stop()
                        return

                bs = soup(s.text, "html.parser")
                secure_code = bs.find("input", {"name": "dwfrm_login_securekey"}).get("value")

                s = self.session_post(cart_url, headers={**headersmain, 'origin': 'https://www.{}.com'.format(self.base), 'referer': "https://www.{}.com/checkout".format(self.base), 'sec-fetch-dest': 'document', 'sec-fetch-mode': 'navigate', 'sec-fetch-user': '?1'}, cookies=cookies, data={"dwfrm_login_unregistered": "Checkout As a Guest", "dwfrm_login_securekey": str(secure_code)})
                cookies = s.cookies.get_dict()
                if not self.restock:
                    self.msg("Getting cookies..", '#FFC300')

                bs = soup(s.text, "html.parser")
                box = bs.find("form").get("action")

                old_dwcont = dwcont
                dwcont = re.search(exp, box, flags=0).group(2)

                if not self.restock:
                    stop = self.msg("Going to checkout..", '#FFC300')
                    if stop:
                        self.stop()
                        return

                if "$0.00" in s.text.lower():
                    stop = self.msg("Waiting for Restock..", "#FFC300")
                    if stop:
                        self.stop()
                        return
                    self.restock = True

                    if self.browser_thread_started and self.browser_thread_complete:
                        for thread in self.browser_threads:
                            thread.join()
                        self.stop()

                    pass
                else:
                    if self.browser_thread_started and self.browser_thread_complete and self.browser is None:
                        self.browser_threads = []
                        self.browser_threads.append(threading.Thread(target=self.browser_thread))
                        self.browser_thread_started = True
                        self.browser_thread_complete = False
                        for thread in self.browser_threads:
                            thread.start()

                    self.keyword_url = found
                    bs = soup(s.text, "html.parser")
                    title = bs.find('img', {"class": 'w-100'}).get('title')
                    self.product_title = title
                    try:
                        update_title(self.task, self.r, title)
                    except:
                        pass
                    break

            cart_url = "https://www.{}.com/checkout?dwcont={}".format(self.base, dwcont)
            old_cart_url = "https://www.{}.com/checkout?dwcont={}".format(self.base, old_dwcont)
            secure_code = bs.find("input", {"name": "dwfrm_singleshipping_securekey"}).get("value")

            stop = self.msg("Submitting shipping..", '#FFC300')
            if stop:
                self.stop()
                return

            shipping_payload = {
                'dwfrm_singleshipping_email_emailAddress': self.billing_email,
                'dwfrm_singleshipping_shippingAddress_addressFields_phone': self.billing_phone,
                'dwfrm_singleshipping_addToEmailList': 'true',
                'dwfrm_singleshipping_shippingAddress_addressFields_firstName': self.billing_firstname,
                'dwfrm_singleshipping_shippingAddress_addressFields_lastName': self.billing_lastname,
                'dwfrm_singleshipping_shippingAddress_addressFields_country': "US",
                'dwfrm_singleshipping_shippingAddress_addressFields_postal': self.billing_zip,
                'dwfrm_singleshipping_shippingAddress_addressFields_address1': self.billing_add1,
                'dwfrm_singleshipping_shippingAddress_addressFields_address2': self.billing_add2,
                'dwfrm_singleshipping_shippingAddress_addressFields_city': self.billing_city,
                'iMoniker': '',
                'dwfrm_singleshipping_shippingAddress_addressFields_states_state': self.billing_state,
                'dwfrm_singleshipping_shippingAddress_useAsBillingAddress': 'true',
                'dwfrm_singleshipping_shippingAddress_shippingMethodID': '7D',
                'dwfrm_singleshipping_shippingAddress_isGift': 'false',
                'dwfrm_singleshipping_shippingAddress_giftMessage': '',
                'dwfrm_singleshipping_shippingAddress_save': 'Continue to Billing',
                'dwfrm_singleshipping_securekey': str(secure_code)
            }

            s = self.session_post(cart_url, headers={**headersmain, 'origin': 'https://www.{}.com'.format(self.base), 'referer': old_cart_url, 'sec-fetch-dest': 'document', 'sec-fetch-mode': 'navigate', 'sec-fetch-user': '?1', 'upgrade-insecure-requests': '1'}, cookies=cookies, data=shipping_payload)

            bs = soup(s.text, "html.parser")
            boxes = bs.find_all("form")
            box = bs.find("form").get("action")
            old_dwcont = dwcont
            dwcont = re.search(exp, box, flags=0).group(2)
            cart_url = "https://www.{}.com/checkout?dwcont={}".format(self.base, dwcont)
            old_cart_url = "https://www.{}.com/checkout?dwcont={}".format(self.base, old_dwcont)

            if len(boxes) > 2:
                s = self.session_post(cart_url, headers={**headersmain, 'referer': old_cart_url, 'sec-fetch-dest': 'document', 'sec-fetch-mode': 'navigate', 'sec-fetch-user': '?1', 'dnt': '1'}, cookies=cookies, data={"dwfrm_addForm_useOrig": ""})

                bs = soup(s.text, "html.parser")
                box = bs.find("form").get("action")
                dwcont = re.search(exp, box, flags=0).group(2)
                cart_url = "https://www.{}.com/checkout?dwcont={}".format(self.base, dwcont)

            print("Waiting for browser..")
            for thread in self.browser_threads:
                thread.join()
            print("Browser is ready..")

            for c in self.session.cookies:
                cook = {'name': c.name, 'value': c.value, 'path': c.path}
                self.browser.add_cookie(cook)
            self.msg("Getting cookies..", '#FFC300')

            self.browser.get(cart_url)

            str_month = self.expmonth
            str_year = self.expyear
            if len(str_month) == 1:
                str_month = "0" + str_month
            if len(str_year) == 4:
                str_year = str_year[2:]

            stop = self.msg("Submitting billing..", '#FFC300')
            if stop:
                self.stop()
                return

            total_breakout = False

            count3 = 0
            while True and not total_breakout:
                count3 += 1
                if count3 >= tries:
                    time.sleep(sleep_time)

                self.msg("Filling form..", '#FFC300')
                try:
                    count4 = 0
                    while True and not total_breakout:
                        count4 += 1
                        print(count4)
                        if count4 >= tries:
                            time.sleep(sleep_time)
                            if count4 >= 130:
                                self.msg("RETRYING..", "#FFC300")
                                send_screenshot(self.browser, ".")
                                self.browser.refresh()
                                count4 = 0
                                #total_breakout = True
                                #break
                        try:
                            iframeName = self.browser.find_element_by_css_selector("iframe#first-data-payment-field-name")
                            if iframeName:
                                break
                        except:
                            pass
                    self.browser.execute_script("document.querySelector('iframe#first-data-payment-field-name').click()")
                    actions = ActionChains(self.browser)
                    actions.send_keys(Keys.TAB * 8)
                    actions.perform()

                    iframeName = self.browser.find_element_by_css_selector("iframe#first-data-payment-field-name")

                    self.browser.switch_to.default_content()
                    self.browser.switch_to.frame(iframeName)
                    set_and_verify(self.browser, "input", self.cardname, send_keys=True, ya=True)

                    self.browser.switch_to.default_content()
                    iframeCard = self.browser.find_element_by_css_selector("iframe#first-data-payment-field-card")
                    self.browser.switch_to.frame(iframeCard)
                    set_and_verify(self.browser, "input#card", self.cardnumber, send_keys=True, ya=True)

                    self.browser.switch_to.default_content()
                    iframeExp = self.browser.find_element_by_css_selector("iframe#first-data-payment-field-exp")
                    self.browser.switch_to.frame(iframeExp)
                    self.browser.switch_to.default_content()
                    iframeExp = self.browser.find_element_by_css_selector("iframe#first-data-payment-field-exp")
                    self.browser.switch_to.frame(iframeExp)
                    set_and_verify(self.browser, "input#exp", "{} / {}".format(str_month, str_year), send_keys=True, ya=True)

                    self.browser.switch_to.default_content()
                    set_and_verify(self.browser, "input.cvn", self.cardcvv, send_keys=True, ya=True)
                    stop = self.msg("Checkout completed..", '#FFC300')
                    if stop:
                        self.stop()
                        return
                    break
                except Exception as e:
                    pass

            declined = False

            count5 = 0
            while True and not total_breakout:
                count5 += 1
                if count5 >= tries:
                    time.sleep(sleep_time)
                try:
                    count6 = 0
                    while True:
                        count6 += 1
                        if count6 >= tries:
                            time.sleep(sleep_time)
                        try:
                            self.browser.execute_script("document.querySelector('div.billing-submit button').click()")
                        except Exception as e:
                            pass
                        try:
                            self.browser.find_element_by_css_selector("button#fsrFocusFirst").click()
                        except Exception as e:
                            pass
                        try:
                            print("breaking..")
                            self.browser.execute_script("document.querySelector('button#summarySubmit').click()")
                            break
                        except Exception as e:
                            #print(str(e))
                            pass

                        if 'style="">invalid card number' in self.browser.page_source.lower():
                            declined = True
                            #time.sleep(1000)
                            break

                    count7 = 0
                    while True:
                        count7 += 1
                        if count7 >= tries:
                            time.sleep(sleep_time)
                        if "thank you for your order" in self.browser.page_source.lower():
                            self.msg("Successful Checkout", '#00FF00')
                            break

                        try:
                            #error_form = self.browser.execute_script("return document.querySelector('div.error-form');")
                            if 1==1:
                                if "your order could not be submitted".lower() in self.browser.page_source.lower():
                                    self.msg("Card Declined", "#FF0000")
                                    #time.sleep(900)
                                    break
                                if declined:
                                    self.msg("Invalid Card Info", "#FF0000")
                                    break
                        except Exception as e:
                            pass
                    break
                except Exception as e:
                    pass

            self.stop()
            if total_breakout:
                self.celery.retry(countdown=3)

        except Exception as e:
            print_error_info(e)
            if self.bad_proxy:
                self.msg("BAD PROXY", "#FF0000")
                self.show_ip()
            if self.lets_restart:
                self.msg("RETRYING", "#FF0000")
                self.celery.retry(countdown=1)
            self.stop()

if __name__ == "__main__":
    bl = HTBL(task, prof, None, None, "https://google.com", "https://google.com", desktop=True, is_ht=True)
    bl.checkout()