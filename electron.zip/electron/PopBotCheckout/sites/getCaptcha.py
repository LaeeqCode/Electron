import requests
from time import sleep
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
def get_captcha(browser, proxy=None, url=None, site_key=None):


    API_KEY = '9ed613a7ebde7c3e55adc3327a8fe83c'  # Your 2captcha API KEY
    s = requests.Session()
    if proxy is None:
        pass
    else:
        s.proxies = {"https": "https://{}".format("{}:{}@{}:{}".format(proxy[0], proxy[1], proxy[2], proxy[3]))}


    if url:
        the_url = url
    else:
        the_url = browser.current_url

    #Getting the data-site key
    options = webdriver.ChromeOptions() 
    options.add_argument("start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    driver = browser
    if site_key is None:
        data_sitekey = WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.CLASS_NAME, "g-recaptcha"))).get_attribute("data-sitekey")
    else:
        data_sitekey = site_key

    print(the_url, ":", data_sitekey)

    #Request to 2captcha to get captcha_id
    captcha_id = s.post("http://2captcha.com/in.php?key={}&method=userrecaptcha&googlekey={}&pageurl={}".format(
        API_KEY, data_sitekey, the_url)).text.split('|')[1]

    # then we parse gresponse from 2captcha response
    recaptcha_answer = s.get(
        "http://2captcha.com/res.php?key={}&action=get&id={}".format(API_KEY, captcha_id)).text
    print("solving ref captcha...")
    print(recaptcha_answer)
    while 'CAPCHA_NOT_READY' in recaptcha_answer:
        print("waiting for captcha.. [{}]".format(recaptcha_answer))
        sleep(5)
        recaptcha_answer = s.get(
            "http://2captcha.com/res.php?key={}&action=get&id={}".format(API_KEY, captcha_id)).text
    print(recaptcha_answer)
    try:
        recaptcha_answer = recaptcha_answer.split('|')[1]
    except:
        recaptcha_answer = get_captcha(browser)
    print("THE ANSWER: {}".format(recaptcha_answer))

    return recaptcha_answer

    
